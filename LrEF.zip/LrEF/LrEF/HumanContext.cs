﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LrEF
{
    public class HumanContext : DbContext
    {
        public HumanContext() : base("DbConnection")
        {

        }
        public DbSet<Human> Humans { get; set; }
    }
}
