﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LrEF
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (HumanContext db = new HumanContext())
            {
                Human human1 = new Human
                {
                    Surname = "Сабиров",
                    Gender = "Male",
                    DateOfBirth = DateTime.Parse("18/01/2004")
                };
                Human human2 = new Human
                {
                    Surname = "Носов",
                    Gender = "Male",
                    DateOfBirth = DateTime.Parse("15/04/2004")
                };

                db.Humans.Add(human1);
                db.Humans.Add(human2);
                db.SaveChanges();
                Console.WriteLine("Объекты успешно сохранены");

                var humans = db.Humans;
                Console.WriteLine("Список объектов:");
                foreach (Human h in humans)
                {
                    Console.WriteLine($"{h.Surname} | {h.Gender} | {h.DateOfBirth}");
                }
            }

            Console.Read();
        }
    }
}
