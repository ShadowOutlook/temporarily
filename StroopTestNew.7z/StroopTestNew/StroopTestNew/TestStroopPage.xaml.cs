﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace StroopTestNew
{
    /// <summary>
    /// Логика взаимодействия для TestStroopPage.xaml
    /// </summary>
    public partial class TestStroopPage : Page
    {
        private Dictionary<string, string> words;

        private int stage;

        private int stageCount;

        private DispatcherTimer _timer;
        private DateTime _startTime;

        private string[] colors;

        public TestStroopPage()
        {
            InitializeComponent();
        }

        private void btnStartTestChapter1_Click(object sender, RoutedEventArgs e)
        {
            ControlBorder.Visibility = Visibility.Collapsed;
            TestChapter1Or3Border.Visibility = Visibility.Visible;

            CreateShuffledWords();
            CreateShuffledColors();
            StartTimer();

            stage = 1;

            stageCount = 10;

            tbxCht1Or3Stage.Text = stage.ToString();

            tbxCht1Or3Variant.Text = words.ElementAt(0).Value;
            tbxCht1Or3Variant.Foreground = new SolidColorBrush(Colors.Black);

            rbCht1Or3Color1.Content = colors[0];
            rbCht1Or3Color2.Content = colors[1];
            rbCht1Or3Color3.Content = colors[2];
            rbCht1Or3Color4.Content = colors[3];
        }

        private void CreateShuffledWords()
        {
            var baseWords = new Dictionary<string, string>
            {
                {"red","КРАСНЫЙ"},
                {"blue", "СИНИЙ" },
                {"yellow", "ЖЕЛТЫЙ"},
                {"black", "ЧЕРНЫЙ"},
                {"red","КРАСНЫЙ"},
                {"blue", "СИНИЙ" },
                {"yellow", "ЖЕЛТЫЙ"},
                {"black", "ЧЕРНЫЙ"},
                {"red","КРАСНЫЙ"},
                {"black", "ЧЕРНЫЙ"},
            };

            var random = new Random();

            var shuffledWords = baseWords.OrderBy(x => random.Next()).ToDictionary(item => item.Key, item => item.Value);

            words = shuffledWords;
        }

        private void CreateShuffledColors()
        {
            string[] baseColors = { "Красный", "Синий", "Желтый", "Черный" };

            var random = new Random();

            var shuffledColors = baseColors.OrderBy(x => random.Next()).ToArray();

            colors = shuffledColors;
        }

        private void StartTimer()
        {
            _startTime = DateTime.Now;
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            TimeSpan elapsed = DateTime.Now - _startTime;
            tbxCht1Or3Timer.Text = elapsed.ToString(@"hh\:mm\:ss");
        }

        private void btnCht1Or3NextQuestion_Click()
        {
            if (stage < stageCount)
            {
                stage += 1;
                tbxCht1Or3Variant.Text = words.ElementAt(stage).Value;
            }


        }

    }
}

