--������� 9

SELECT StudentSurname, StudentName, Scholarship FROM Student;

BEGIN TRANSACTION;

UPDATE Student SET Scholarship=10000;

SELECT StudentSurname, StudentName, Scholarship FROM Student;

SAVE TRANSACTION SavePoint1;

UPDATE Student SET Scholarship=0;

SELECT StudentSurname, StudentName, Scholarship FROM Student;

ROLLBACK TRANSACTION SavePoint1;

COMMIT TRANSACTION;

SELECT StudentSurname, StudentName, Scholarship FROM Student;
