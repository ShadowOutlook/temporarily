--������� 6

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRANSACTION
SELECT StudentSurname, StudentName FROM Student
DELETE Student WHERE StudentSurname='�����'
SELECT StudentSurname, StudentName FROM Student

ROLLBACK;
--COMMIT TRANSACTION