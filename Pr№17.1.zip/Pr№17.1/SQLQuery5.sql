SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

BEGIN TRANSACTION
SELECT StudentSurname, StudentName FROM Student;
DELETE Student WHERE StudentSurname='C���������';
SELECT StudentSurname, StudentName FROM Student;

--ROLLBACK TRANSACTION

BEGIN TRANSACTION
INSERT INTO Student (StudentSurname, StudentName, DateOfBirth) VALUES('�������', '������', '10.10.2001');
SELECT StudentSurname, StudentName FROM Student;

--COMMIT TRANSACTION