--������� 7

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRANSACTION;

SELECT StudentSurname, StudentName, DateOfBirth, Scholarship FROM Student;

UPDATE Student SET Scholarship+=500 WHERE YEAR(DateOfBirth)='2004';

SELECT StudentSurname, StudentName, DateOfBirth, Scholarship FROM Student;

ROLLBACK TRANSACTION;

SELECT StudentSurname, StudentName, DateOfBirth, Scholarship FROM Student;

BEGIN TRANSACTION;

UPDATE Student SET Scholarship+=500 WHERE YEAR(DateOfBirth)='2004';

SELECT StudentSurname, StudentName, DateOfBirth, Scholarship FROM Student;

COMMIT TRANSACTION;

SELECT StudentSurname, StudentName, DateOfBirth, Scholarship FROM Student;
