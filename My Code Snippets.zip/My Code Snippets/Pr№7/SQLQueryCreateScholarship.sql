ALTER TABLE Student
ADD Scholarship MONEY;