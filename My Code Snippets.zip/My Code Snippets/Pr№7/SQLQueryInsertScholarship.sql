USE IAb221_SabirovU;

UPDATE Student
SET Scholarship = 1001
WHERE StudentId = 1;

UPDATE Student
SET Scholarship = 3000
WHERE StudentId = 2;

UPDATE Student
SET Scholarship = 13700
WHERE StudentId = 3;

UPDATE Student
SET Scholarship = 999
WHERE StudentId = 4;

UPDATE Student
SET Scholarship = 100
WHERE StudentId = 5;

UPDATE Student
SET Scholarship = 6
WHERE StudentId = 6;

UPDATE Student
SET Scholarship = 7000
WHERE StudentId = 7;

UPDATE Student
SET Scholarship = 6969
WHERE StudentId = 8;