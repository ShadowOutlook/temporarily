DELETE FROM [Group];

DELETE FROM Discipline;

DELETE FROM Teacher;

DELETE FROM Student;

DELETE FROM Award;

DELETE FROM Grade;

DELETE FROM TeacherDisciplineGroup;

DELETE FROM AwardStudent;

DELETE FROM Performance;

DELETE FROM Hobbies;

DELETE FROM HobbieStudent;