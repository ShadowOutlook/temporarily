USE IAb221_SabirovU;

ALTER TABLE Discipline
ADD BriefDescripiton VARCHAR(255);

ALTER TABLE Teacher
ADD PhotoOfTheTeacher VARBINARY(MAX);