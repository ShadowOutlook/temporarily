USE IAb221_SabirovU;

SELECT StudentSurname, StudentName
FROM Student
WHERE StudentSurname LIKE '%���%';