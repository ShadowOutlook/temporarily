SELECT TeacherSurname, TeacherName, TeacherPatronymic
FROM Teacher
WHERE TeacherSurname LIKE '�%';