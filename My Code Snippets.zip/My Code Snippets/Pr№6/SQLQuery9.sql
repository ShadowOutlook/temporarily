SELECT TOP 10 DisciplineName
FROM Discipline
WHERE DisciplineId LIKE '1970%'
ORDER BY DisciplineName;