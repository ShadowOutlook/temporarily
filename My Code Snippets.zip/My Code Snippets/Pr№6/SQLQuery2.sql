USE IAb221_SabirovU;

SELECT CONCAT (StudentSurname, ' ', StudentName, ' ', StudentPatronymic) AS ���, Email, DateOfBirth
FROM Student
WHERE DateOfBirth = '2000-12-12';