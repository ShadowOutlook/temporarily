﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LrWPF2
{
    public class Doctor
    {
        [Key]
        public int DoctorId { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Patronymic { get; set; }
        public int CategoryId { get; set; }
        public DateTime DateOfBirth { get; set; }

        public virtual User User { get; set; }
        public virtual Category Category { get; set; }
    }
}
