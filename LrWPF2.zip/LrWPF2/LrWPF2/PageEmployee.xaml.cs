﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LrWPF2
{
    /// <summary>
    /// Логика взаимодействия для PageEmployee.xaml
    /// </summary>
    public partial class PageEmployee : Page
    {
        public static ApplicationDbContext dbData { get; set; }

        public PageEmployee()
        {
            InitializeComponent();

            if (dbData == null)
            {
                dbData = new ApplicationDbContext();
            }

            DataGridEmployee.ItemsSource = dbData.Doctors.ToList();

            addCmbCategory();
        }

        private void addCmbCategory()
        {
            foreach (Category c in dbData.Categories)
            {
                cmbCategory.Items.Add(c.Name);
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            DataGridEmployee.IsReadOnly = false;
            
            if (DataGridEmployee.SelectedItem != null)
            {
                var cell = DataGridEmployee.SelectedCells[0];
                DataGridEmployee.CurrentCell = cell;
            }
            else
            {
                DataGridEmployee.CurrentCell = new DataGridCellInfo(DataGridEmployee.Items[0], DataGridEmployee.Columns[0]);
            }

            DataGridEmployee.BeginEdit();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            dbData.SaveChanges();
            DataGridEmployee.IsReadOnly = true;
            MessageBox.Show("Данные успешно отредактированы");
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Doctor doctor = DataGridEmployee.SelectedItem as Doctor;
            if (doctor != null)
            {
                MessageBoxResult result = MessageBox.Show($"Удалить сотрудника {doctor.Surname} {doctor.Name} {doctor.Patronymic}", "Предупреждение", MessageBoxButton.OKCancel);

                if (result == MessageBoxResult.OK)
                {
                    User user = doctor.User;
                    dbData.Doctors.Remove(doctor);
                    dbData.Users.Remove(user);
                    dbData.SaveChanges();
                    DataGridEmployee.ItemsSource = dbData.Doctors.ToList();
                }

                DataGridEmployee.SelectedIndex = -1;
            }
            else
            {
                MessageBox.Show("Выберите строку для удаления");
            }
        }

        private void btnOpen_Click(object sender, RoutedEventArgs e)
        {
            if (sender == btnAdd)
            {
                BorderEnterData.Visibility = Visibility.Visible;
            }
            if (sender == btnFind)
            {
                BorderFind.Visibility = Visibility.Visible;
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;

            if (clickedButton != null)
            {
                Border parentBorder = null;

                if (clickedButton.Name == "btnEnterDataExit")
                {
                    parentBorder = BorderEnterData;
                }
                else if (clickedButton.Name == "btnFindExit")
                {
                    parentBorder = BorderFind;
                }

                if (parentBorder != null)
                {
                    ClearFields(parentBorder);
                    parentBorder.Visibility = Visibility.Hidden;
                }
            }
        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            bool existLogin = false;

            var users = dbData.Users;
            foreach (User u in users)
            {
                if (tbxLogin.Text == u.Login)
                {
                    MessageBox.Show("Такой логин уже существует");
                    
                    existLogin = true;
                    break;
                }
            }

            if (!existLogin)
            {
                int maxUserId = (from us in dbData.Users
                                 select us.UserId).Max();

                User user = new User();
                user.Login = tbxLogin.Text;
                user.Password = PageMain.GetHash(tbxPassword.Text);
                user.Type = "doctor";
                user.UserId = maxUserId + 1;
                dbData.Users.Add(user);
                dbData.SaveChanges();

                Doctor doctor = new Doctor();
                doctor.Surname = tbxSurname.Text;
                doctor.Name = tbxName.Text;
                doctor.Patronymic = tbxPatronymic.Text;

                var idCategory = from cat in dbData.Categories
                                 where cat.Name == (cmbCategory.SelectedItem).ToString()
                                 select cat.CategoryId;

                doctor.CategoryId = idCategory.First();
                doctor.DateOfBirth = DateTime.Parse(tbxDateOfBirth.Text);
                doctor.User = user;
                dbData.Doctors.Add(doctor);
                dbData.SaveChanges();

                DataGridEmployee.ItemsSource = dbData.Doctors.ToList();

                BorderEnterData.Visibility = Visibility.Hidden;

                MessageBox.Show("Данные успешно сохранены");
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            BorderFind.Visibility = Visibility.Visible;

            DateTime DateOfBirth = DateTime.Parse(tbxDateOfBirthFind.Text);

            if (tbxSurnameFind.Text != "" && tbxDateOfBirthFind.Text != "")
            {
                string result = "";

                var queryFind = from d in dbData.Doctors
                                where d.Surname == tbxSurnameFind.Text
                                && d.DateOfBirth == DateOfBirth
                                join c in dbData.Categories
                                on d.CategoryId equals c.CategoryId
                                select d;

                foreach (Doctor d in queryFind)
                {
                    result = result + $"{d.Surname} {d.Name} {d.Patronymic} {d.DateOfBirth} {d.Category.Name}" + Environment.NewLine;
                }

                if (result != "")
                {
                    BorderFind.Visibility = Visibility.Hidden;

                    MessageBox.Show(result);
                }
                else
                {
                    MessageBox.Show("Пользователь не найден!");
                }
            }
        }

        private void ClearFields(DependencyObject parent)
        {
            // Проходим по всем дочерним элементам
            foreach (var child in LogicalTreeHelper.GetChildren(parent))
            {
                if (child is TextBox textBox)
                {
                    textBox.Clear();
                }
                else if (child is ComboBox comboBox)
                {
                    comboBox.SelectedIndex = -1;
                }
                else if (child is DependencyObject dependencyObject)
                {
                    ClearFields(dependencyObject); // Рекурсивный вызов для вложенных элементов
                }
            }
        }
    }
}
