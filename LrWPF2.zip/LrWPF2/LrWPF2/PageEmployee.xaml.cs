﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LrWPF2
{
    /// <summary>
    /// Логика взаимодействия для PageEmployee.xaml
    /// </summary>
    public partial class PageEmployee : Page
    {
        public static ApplicationDbContext dbData { get; set; }

        public PageEmployee()
        {
            InitializeComponent();
            if (dbData == null)
            {
                dbData = new ApplicationDbContext();
            }

            DataGridEmployee.ItemsSource = dbData.Doctors.ToList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            DataGridEmployee.IsReadOnly = false;
            
            if (DataGridEmployee.SelectedItem != null)
            {
                var cell = DataGridEmployee.SelectedCells[0];
                DataGridEmployee.CurrentCell = cell;
            }
            else
            {
                DataGridEmployee.CurrentCell = new DataGridCellInfo(DataGridEmployee.Items[0], DataGridEmployee.Columns[0]);
            }

            DataGridEmployee.BeginEdit();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Doctor doctor = DataGridEmployee.SelectedItem as Doctor;
            if (doctor != null)
            {
                MessageBoxResult result = MessageBox.Show($"Удалить сотрудника {doctor.Surname} {doctor.Name} {doctor.Patronymic}", "Предупреждение", MessageBoxButton.OKCancel);

                if (result == MessageBoxResult.OK)
                {
                    dbData.Doctors.Remove(doctor);
                    dbData.SaveChanges();
                    DataGridEmployee.ItemsSource = dbData.Doctors.ToList();
                }

                DataGridEmployee.SelectedIndex = -1;
            }
            else
            {
                MessageBox.Show("Выберите строку для удаления");
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            dbData.SaveChanges();
            DataGridEmployee.IsReadOnly = true;
            MessageBox.Show("Данные успешно сохранены");
        }
    }
}
