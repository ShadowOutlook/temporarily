﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace LrWPF2.Models
{
    public class ListCategory : ObservableCollection<Category>
    {
        public ListCategory()
        {
            if (PageEmployee.dbData == null)
            {
                PageEmployee.dbData = new ApplicationDbContext();
            }
            var queryCategory = from c in PageEmployee.dbData.Categories select c;
            foreach (Category cat in queryCategory)
            {
                this.Add(cat);
            }
        }
    }
}
