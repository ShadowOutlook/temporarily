﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LrWPF2
{
    public class Patient
    {
        [Key]
        public int PatientId { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Patronymic { get; set; }
        public DateTime DateOfBirth { get; set; }
        public int NumPolice { get; set; }
        public string InsuranceCompany { get; set; }

        public User User { get; set; }
    }
}
