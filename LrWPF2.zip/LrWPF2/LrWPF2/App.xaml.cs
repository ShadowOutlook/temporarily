﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace LrWPF2
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            InitializeDatabase();
        }

        private void InitializeDatabase()
        {
            using (var db = new ApplicationDbContext())
            {
                if (!db.Users.Any())
                {
                    CreateAllRecord();
                }
            }
        }

        private void CreateAllRecord()
        {
            using (var db = new ApplicationDbContext())
            {
                Category category1 = new Category { Name = "первая" };
                Category category2 = new Category { Name = "вторая" };
                Category categoryH = new Category { Name = "высшая" };

                db.Categories.Add(category1);
                db.Categories.Add(category2);
                db.Categories.Add(categoryH);
                db.SaveChanges();

                User user1 = new User { Login = "login1", Password = "password1", Type = "doctor" };
                User user2 = new User { Login = "login2", Password = "password2", Type = "doctor" };
                User user3 = new User { Login = "login3", Password = "password3", Type = "patient" };
                User user4 = new User { Login = "login4", Password = "password4", Type = "patient" };
                User user5 = new User { Login = "login5", Password = "password5", Type = "doctor" };
                User user6 = new User { Login = "login6", Password = "password6", Type = "doctor" };
                User user7 = new User { Login = "admin", Password = "123", Type = "admin" };

                db.Users.Add(user1);
                db.Users.Add(user2);
                db.Users.Add(user3);
                db.Users.Add(user4);
                db.Users.Add(user5);
                db.Users.Add(user6);
                db.Users.Add(user7);
                db.SaveChanges();


                Doctor doctor1 = new Doctor { Surname = "Лидия", Name = "Ивановна", Patronymic = "Сапожникова", Category = category1, DateOfBirth = DateTime.Parse("01/01/2001"), User = user1 };
                Doctor doctor2 = new Doctor { Surname = "Ирина", Name = "Павловна", Patronymic = "Синельникова", Category = category2, DateOfBirth = DateTime.Parse("06/03/2022"), User = user2 };
                Doctor doctor3 = new Doctor { Surname = "Иван", Name = "Иванович", Patronymic = "Новиков-Приблудников", Category = category1, DateOfBirth = DateTime.Parse("06/03/2022"), User = user5 };
                Doctor doctor4 = new Doctor { Surname = "Илья", Name = "Павлович", Patronymic = "Сидоров", Category = category1, DateOfBirth = DateTime.Parse("06/03/2022"), User = user6 };

                db.Doctors.Add(doctor1);
                db.Doctors.Add(doctor2);
                db.Doctors.Add(doctor3);
                db.Doctors.Add(doctor4);
                db.SaveChanges();

                Patient patient1 = new Patient { Surname = "Александров", Name = "Петр", Patronymic = "Иванович", DateOfBirth = DateTime.Parse("15.03.1985"), NumPolice = 1, InsuranceCompany = "Гарантия жизни", User = user3 };
                Patient patient2 = new Patient { Surname = "Смирнова", Name = "Елена", Patronymic = "Викторовна", DateOfBirth = DateTime.Parse("22.07.1992"), NumPolice = 2, InsuranceCompany = "Щит и опора", User = user4 };

                db.Patients.Add(patient1);
                db.Patients.Add(patient2);
                db.SaveChanges();

                Admin admin1 = new Admin { Surname = "Кузнецов", Name = "Андрей", User = user7 };

                db.Admins.Add(admin1);
                db.SaveChanges();
            }
        }
    }
}
