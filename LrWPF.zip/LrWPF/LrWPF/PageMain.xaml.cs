﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Security.Cryptography;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LrWPF
{
    /// <summary>
    /// Логика взаимодействия для PageMain.xaml
    /// </summary>
    public partial class PageMain : Page
    {
        static public string userSurname = "";
        static public string userName = "";
        static public int userId;
        static ApplicationDbContext dbContext = new ApplicationDbContext();
        static public int initialUsers = dbContext.Users.Count();

        public PageMain()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            bool valid = false;
            string userType = "";
            var db = new ApplicationDbContext();

            using (db)
            {
                var users = db.Users.ToList();
                foreach (User u in users)
                {
                    string enteredPassword = u.UserId > initialUsers ? PageRegistration.GetHash(tbxPassword_.Password) : tbxPassword_.Password;

                    if (tbxLogin_.Text == u.Login & enteredPassword == u.Password)
                    {
                        valid = true;
                        userType = u.Type;

                        if (userType == "doctor")
                        {
                            var queryDoctor = from d in db.Doctors
                                              where d.User.UserId == u.UserId
                                              select d;
                            var doctorList = queryDoctor.ToList();

                            foreach (Doctor d in doctorList)
                            {
                                userSurname = d.Surname;
                                userName = d.Name;
                                userId = d.DoctorId;
                            }
                        }
                        if (userType == "patient")
                        {
                            var queryPatient = from p in db.Patients
                                               where p.User.UserId == u.UserId
                                               select p;
                            var patientList = queryPatient.ToList();

                            foreach (Patient p in patientList)
                            {
                                userSurname = p.Surname;
                                userName = p.Name;
                                userId = p.PatientId;
                            }
                        }
                        if (userType == "admin")
                        {
                            var queryAdmin = from a in db.Admins
                                             where a.User.UserId == u.UserId
                                             select a;
                            var adminList = queryAdmin.ToList();

                            foreach (Admin a in adminList)
                            {
                                userSurname = a.Surname;
                                userName = a.Name;
                                userId = a.AdminId;
                                WindowNavigationPage windowNavigationPage = new WindowNavigationPage();
                                windowNavigationPage.Show();
                                App.Current.MainWindow.Close();
                            }
                        }
                    }
                }
            }
            if (valid)
            {
                MessageBox.Show($"Верный логин или пароль! Это {userType}, {userSurname} {userName}");
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль");
            }
        }
    }
}
