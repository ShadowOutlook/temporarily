﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LrWPF
{
    public class Program
    {
        static void Main(string[] args)
        {
            CreateUserReсord();
            CreateDoctorRecord();
            CreatePatientRecord();
            CreateAdminRecord();
        }

        static void CreateUserReсord()
        {
            using(ApplicationDbContext db = new ApplicationDbContext())
            {
                User user1 = new User
                {
                    Login = "login1",
                    Password = "password1",
                    Type = "doctor"
                };

                User user2 = new User
                {
                    Login = "login2",
                    Password = "password2",
                    Type = "doctor"
                };

                User user3 = new User
                {
                    Login = "login3",
                    Password = "password3",
                    Type = "patient"
                };

                User user4 = new User
                {
                    Login = "login4",
                    Password = "password4",
                    Type = "patient"
                };

                User user5 = new User
                {
                    Login = "login5",
                    Password = "password5",
                    Type = "doctor"
                };

                User user6 = new User
                {
                    Login = "login6",
                    Password = "password6",
                    Type = "doctor"
                };

                User admin = new User
                {
                    Login = "admin",
                    Password = "123",
                    Type = "admin"
                };

                db.Users.Add(user1);
                db.Users.Add(user2);
                db.Users.Add(user3);
                db.Users.Add(user4);
                db.Users.Add(user5);
                db.Users.Add(user6);
                db.Users.Add(admin);
                db.SaveChanges();
                Console.WriteLine("Объекты users успешно сохранены");
            }
        }

        static void CreateDoctorRecord()
        {
            using(ApplicationDbContext db = new ApplicationDbContext())
            {
                Doctor doctor1 = new Doctor
                {
                    Surname = "Лидия",
                    Name = "Ивановна",
                    Patronymic = "Сапожникова",
                    CategoryId = 1,
                    DateOfBirth = DateTime.Parse("01/01/2001"),
                    UserId = 1
                };

                Doctor doctor2 = new Doctor
                {
                    Surname = "Ирина",
                    Name = "Павловна",
                    Patronymic = "Синельникова",
                    CategoryId = 2,
                    DateOfBirth = DateTime.Parse("06/03/2022"),
                    UserId = 2
                };

                Doctor doctor3 = new Doctor
                {
                    Surname = "Иван",
                    Name = "Иванович",
                    Patronymic = "Новиков-Приблудников",
                    CategoryId = 1,
                    DateOfBirth = DateTime.Parse("06/03/2022"),
                    UserId = 5
                };

                Doctor doctor4 = new Doctor
                {
                    Surname = "Илья",
                    Name = "Павлович",
                    Patronymic = "Сидоров",
                    CategoryId = 1,
                    DateOfBirth = DateTime.Parse("06/03/2022"),
                    UserId = 6
                };

                db.Doctors.Add(doctor1);
                db.Doctors.Add(doctor2);
                db.Doctors.Add(doctor3);
                db.Doctors.Add(doctor4);
            }
        }

        static void CreatePatientRecord()
        {
            using(ApplicationDbContext db = new ApplicationDbContext())
            {
                Patient patient1 = new Patient
                {
                    Surname = "Александров",
                    Name = "Петр",
                    Patronymic = "Иванович",
                    DateOfBirth = DateTime.Parse("15.03.1985"),
                    NumPolice = 1,
                    InsuranceCompany = "Гарантия жизни",
                    UserId = 3
                };

                Patient patient2 = new Patient
                {
                    Surname = "Смирнова",
                    Name = "Елена",
                    Patronymic = "Викторовна",
                    DateOfBirth = DateTime.Parse("22.07.1992"),
                    NumPolice = 2,
                    InsuranceCompany = "Щит и опора",
                    UserId = 4
                };
            }
        }

        static void CreateAdminRecord()
        {
            using(ApplicationDbContext db = new ApplicationDbContext())
            {
                Admin admin1 = new Admin
                {
                    Surname = "Кузнецов",
                    Name = "Андрей",
                    UserId = 7
                };
            }
        }
    }
}
