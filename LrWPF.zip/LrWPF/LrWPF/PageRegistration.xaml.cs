﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Security.Cryptography;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LrWPF
{
    /// <summary>
    /// Логика взаимодействия для PageRegistration.xaml
    /// </summary>
    public partial class PageRegistration : Page
    {
        public PageRegistration()
        {
            InitializeComponent();
            addCmbCategory();
        }

        private void addCmbCategory()
        {
            var db = new ApplicationDbContext();

            using (db)
            {
                foreach (Category c in db.Categories)
                {
                    cmbCategory_.Items.Add(c.Name);
                }
            }
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            bool existLogin = false;
            var db = new ApplicationDbContext();

            using (db)
            {
                var users = db.Users;

                foreach (User u in users)
                {
                    if (tbxLogin_.Text == u.Login)
                    {
                        MessageBox.Show("Такой логин уже существует");
                        existLogin = true;
                    }
                }
            }

            if (!existLogin)
            {
                var db1 = new ApplicationDbContext();

                using (db1)
                {
                    int maxUserId = (from us in db1.Users
                                     select us.UserId).Max();

                    User user = new User();
                    user.Login = tbxLogin_.Text;
                    user.Password = GetHash(tbxPassword_.Text);
                    user.Type = "doctor";
                    user.UserId = maxUserId + 1;
                    db1.Users.Add(user);
                    db1.SaveChanges();

                    Doctor doctor = new Doctor();
                    doctor.Surname = tbxSurname_.Text;
                    doctor.Name = tbxName_.Text;
                    doctor.Patronymic = tbxPatronymic_.Text;

                    var idCategory = from cat in db1.Categories
                                     where cat.Name == (cmbCategory_.SelectedItem).ToString()
                                     select cat.CategoryId;

                    doctor.CategoryId = idCategory.First();
                    doctor.DateOfBirth = DateTime.Parse(tbxDateOfBirth_.Text);
                    doctor.User = user;
                    db1.Doctors.Add(doctor);
                    db1.SaveChanges();
                    MessageBox.Show("Регистрация прошла успешно!");
                    NavigationService.Navigate(new Uri("PageMain.xaml", UriKind.Relative));
                }
            }
        }

        public static string GetHash(string input)
        {
            var md5 = MD5.Create();
            var hash = md5.ComputeHash(Encoding.UTF8.GetBytes(input));
            return Convert.ToBase64String(hash);
        }
    }
}
