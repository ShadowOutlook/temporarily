﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace LrWPF
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext() : base("DbConnection")
        {

        }

        public DbSet<User> Users { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Patient> Patient { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Admin>()
                .HasRequired(a => a.User)
                .WithRequiredPrincipal(u => u.Admin);

            modelBuilder.Entity<Doctor>()
                .HasRequired(d => d.User)
                .WithRequiredPrincipal(u => u.Doctor);

            modelBuilder.Entity<Patient>()
                .HasRequired(p => p.User)
                .WithRequiredPrincipal(u => u.Patient);
        }
    }
}
