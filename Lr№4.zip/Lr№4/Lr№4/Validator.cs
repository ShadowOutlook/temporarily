﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Lr_4
{
    class Validator
    {
        public string Line(string value) // Проверка на введение строки
        {
            while (int.TryParse(value, out _) || string.IsNullOrEmpty(value) || value.Contains(" ") || !Regex.IsMatch(value, @"[а-яА-Я]"))
            {
                Console.Write("Введите верное значение!: ");

                value = Console.ReadLine();
            }

            return value;
        }

        public string Number(string value) // Проверка на введение числа
        {
            while (!int.TryParse(value, out _) || string.IsNullOrEmpty(value) || value.Contains(" ") || !Regex.IsMatch(value, @"[0-9]"))
            {
                Console.Write("Введите верное значение!: ");

                value = Console.ReadLine();
            }

            return value;
        }

        public int Variant(string value, int min, int max) // Проверка на ввод из вариантов чисел
        {
            value = Number(value);

            while (Convert.ToInt32(value) < min || Convert.ToInt32(value) > max || value == "-0")
            {
                Console.Write("Введите верное значение!: ");

                value = Number(Console.ReadLine());
            }

            return Convert.ToInt32(value);
        }

        public string GetInput(string prompt) // Метод задания вопроса и получения на него ответа при вводе данных
        {
            Console.Write(prompt);
            return Console.ReadLine();
        }

        public DateTime CorrectDateTime(string value)
        {
            while(DateTime.TryParseExact(value, "dd.MM.yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime validDate))
            {
                value = Line(GetInput("Введите дату согласно формату dd.MM.yyyy: "));
            }

            return Convert.ToDateTime(value);
        }

        public string ReturnChoise(string value, int max)
        {
            while(true)
            {
                if (int.TryParse(value, out _))
                {
                    if (1 < Convert.ToInt32(value) && Convert.ToInt32(value) < max)
                    {
                        break;
                    }
                    else
                    {
                        value = GetInput("Введенное вами значение выходит за пределы допустимых значений, введите корректное значение: ");
                    }
                }
                else if (value == "\n")
                {
                    break;
                }
                else
                {
                    value = GetInput("Введите корректное значение: ");
                }
            }

            return value;
        }

        public string ReturnSpecial(string value, DateTime creationDate)
        {
            while (true)
            {
                if (DateTime.TryParseExact(value, "dd.MM.yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime validDate))
                {
                    if (Convert.ToDateTime(value) > creationDate)
                    {
                        break;
                    }
                    else
                    {
                        value = GetInput("Введенная вами дата не может быть ранее даты создания записи, введите корректную дату: ");
                    }
                }
                else if (value == "\n")
                {
                    break;
                }
                else
                {
                    value = GetInput("Введите корректное значение: ");
                }
            }

            return value;
        }
    }
}
