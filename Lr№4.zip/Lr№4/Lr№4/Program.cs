﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lr_4
{
    internal class Program
    {

        enum Category
        {
            WorkNote,
            HomeNote,
            HealthNote,
        }

        static void Main(string[] args)
        {
            Validator validator = new Validator();

            string categories = "Выберите категорию:" +
                                "\nРабота" +
                                "\nДом" +
                                "\nЗдоровье" +
                                "\n\nВвод: ";

            Dictionary<int, Action<string>> actions = new Dictionary<int, Action<string>>
            {
                { 1, CreateNewNote },
                { 2, EditNote },
                { 3, ViewNote },
                { 4, ViewActualNote },
            };

            Dictionary<Category, List<NoteBook>> Note = new Dictionary<Category, List<NoteBook>>
            {
                { Category.WorkNote, new List<NoteBook>() },
                { Category.HomeNote, new List<NoteBook>() },
                { Category.HealthNote, new List<NoteBook>() },
            };

            string actionList = "Выберите действие, введя номер:" +
                                "\n1 - Создать новую заметку" +
                                "\n2 - Отредактировать заметку" +
                                "\n3 - Просмотреть заметку" +
                                "\n4 - Просмтреть актуальные заметки" +
                                "\n5 -  Закончить" +
                                "\n\nВвод: ";

            bool exit = false;

            while (!exit)
            {
                int oneAction = validator.Variant(GetInput(actionList), 1, 4);

                if (actions.ContainsKey(oneAction))
                {
                    actions[oneAction](categories);
                }
                else
                {
                    exit = true;
                }
            }

            if (exit)
            {
                Console.WriteLine("Завершение работы программы!" +
                                  "\nПрограмма завершена. Нажмите любую клавишу, чтобы закрыть консоль.");
                Console.ReadKey();
            }
        }
        private static string GetInput(string prompt) // Метод задания вопроса и получения на него ответа при вводе данных
        {
            Console.Write(prompt);
            return Console.ReadLine();
        }

        static void CreateNewNote(string categories)
        {
            Validator validator = new Validator();
            int oneCategory = validator.Variant(GetInput(categories), 1, 3);

        }

        static void EditNote(string categories)
        {
            Validator validator = new Validator();
            int oneCategory = validator.Variant(GetInput(categories), 1, 3);
        }

        static void ViewNote(string categories)
        {
            Validator validator = new Validator();
            int oneCategory = validator.Variant(GetInput(categories), 1, 3);
        }

        static void ViewActualNote(string categories)
        {
            Validator validator = new Validator();
            int oneCategory = validator.Variant(GetInput(categories), 1, 3);
        }

    }
}
