﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Lr_4
{
    abstract class NoteBook
    {
        Validator validator = new Validator();

        private DateTime _creationDate;

        public DateTime CreationDate
        {
            get
            {
                return _creationDate;
            }

            set
            {
                _creationDate = value;
            }
        }

        public void ChangeCreationDate()
        {
            CreationDate = validator.CorrectDateTime(validator.GetInput("Дата создания: "));
        }

        public abstract void InfoOutput();

        public abstract void CreateNote();

        public abstract void EditNote();

        public abstract void ViewNote();
    }

    enum PriorityLevel { Низкий, Средний, Высокий }

    enum TaskStatus {НеНачата, ВПроцессе, Завершена }

    enum FrequencyType { Ежедневно, Еженедельно, Ежемесячно, Разово }

    enum AppointmentStatus { Запланировано, Завершено, Отменено }

    class WorkNote : NoteBook
    {
        Validator validator = new Validator();

        private string _projectName;
        private string _taskDescription;
        private PriorityLevel _priority;
        private TaskStatus _status;
        private DateTime _dueDate;
        private string _assignedTo;
        private List<string> _comments;

        public string ProjectName
        {
            get
            {
                return _projectName;
            }

            set
            {
                _projectName = value;
            }
        }

        public string TaskDescription
        {
            get
            {
                return _taskDescription;
            }

            set
            {
                _taskDescription = value;
            }
        }

        public PriorityLevel Priority
        {
            get
            {
                return _priority;
            }

            set
            {
                _priority = value;
            }
        }

        public TaskStatus Status
        {
            get
            {
                return _status;
            }

            set
            {
                _status = value;
            }
        }

        public DateTime DueDate
        {
            get
            {
                return _dueDate;
            }

            set
            {
                _dueDate = value;
            }
        }

        public string AssignedTo
        {
            get
            {
                return _assignedTo;
            }

            set
            {
                _assignedTo = value;
            }
        }

        public List<string> Comments
        {
            get
            {
                return _comments;
            }

            set
            {
                _comments = value;
            }
        }

        public static string ReturnEnums<T>() where T : Enum
        {
            string enums = "";

            foreach (var value in Enum.GetValues(typeof(T)))
            {
                enums += $"\n{(int)value} - {value.ToString()}";
            }

            return enums;
        }

        string priorities = ReturnEnums<PriorityLevel>();
        string statuses = ReturnEnums<TaskStatus>();

        PriorityLevel[] priorityLevels = (PriorityLevel[])Enum.GetValues(typeof(PriorityLevel));
        TaskStatus[] taskStatuses = (TaskStatus[])Enum.GetValues(typeof(TaskStatus));

        string actionList = "\n1 - Добавить новый коментарий" + "\n2 - Удалить конкретный коментарий" + "\n3 - Отредактировать конкретный коментарий" + "\n4 - Очистить все коментарии" + "\n5 - Пропустить";

        public static T Next<T>(T value, T byDefault, object condition)
        {
            T result;

            if (value.Equals(condition))
            {
                result = byDefault;
            }
            else
            {
                result = value;
            }

            return result;
        }

        public override void InfoOutput()
        {
            Console.WriteLine("Работа:" +
                              $"\n{new string(Convert.ToChar("-"), 64)}" +
                              $"\nНазвание: {_projectName}" +
                              $"\nОписание: {_taskDescription}" +
                              $"\nПриоритет:{_priority}" +
                              $"\nСтатус: {_status}" +
                              $"\nСрок сдачи до:{_dueDate}" +
                              $"\nНазначено: {_assignedTo}" +
                              $"\nКоментарии:\n{string.Join("\n", _comments)}"
                             );
        }

        public override void CreateNote()
        {
            CreationDate = DateTime.Now.Date;

            ProjectName = validator.Line(validator.GetInput("Название: "));

            TaskDescription = validator.Line(validator.GetInput("Описание: "));

            Priority = (PriorityLevel)validator.Variant(
                                                         validator.GetInput(
                                                                            "Выберите приоритет из следующих вариантов, введя номер:" +
                                                                            priorities +
                                                                            "\n\nВвод: "
                                                                           ),
                                                         1,
                                                         Enum.GetValues(typeof(PriorityLevel)).Length
                                                        ) - 1;

            Status = (TaskStatus)validator.Variant(
                                                    validator.GetInput(
                                                                       "Выберите статус из следующих вариантов, введя номер:" +
                                                                       statuses +
                                                                       "\n\nВвод: "
                                                                      ),
                                                    1,
                                                    Enum.GetValues(typeof(TaskStatus)).Length
                                                   ) - 1;

            DueDate = validator.CorrectDateTime(validator.GetInput("Срок сдачи до: "));

            while (DueDate < CreationDate)
            {
                DueDate = validator.CorrectDateTime(validator.GetInput("Введенная вами дата не может быть ранее даты создания записи, введите корректную дату: "));
            }

            AssignedTo = validator.Line(validator.GetInput("Назначено: "));

            Comments.Add(validator.Line(validator.GetInput("Комментарий: ")));
        }

        public override void EditNote()
        {
            int indexComment;

            Console.WriteLine("Какие свойства вы хотите изменить, для сохранения по умолчанию нажмите Enter:");

            ProjectName = Next(
                                validator.Line(validator.GetInput($"Название проекта (по умолчанию - {ProjectName}): ")),
                                ProjectName,
                                "\n"
                               );

            TaskDescription = Next(
                                    validator.Line(validator.GetInput($"Описание проекта (по умолчанию - {TaskDescription}): ")),
                                    TaskDescription,
                                    "\n"
                                   );

            int indexPriority = Convert.ToInt32(Next(
                                                     validator.ReturnChoise(
                                                                            validator.GetInput(
                                                                                               $"Выберите приоритет проекта из следующих вариантов, введя номер (по умолчанию - {Priority}):" +
                                                                                               priorities +
                                                                                               "\n\nВвод: "
                                                                                              ),
                                                                            Enum.GetValues(typeof(PriorityLevel)).Length
                                                                           ),
                                                     Convert.ToString(Array.IndexOf(priorityLevels, Priority)), 
                                                     "\n"
                                                    )
                                               );

            Priority = (PriorityLevel)indexPriority;

            int indexStatus = Convert.ToInt32(Next(
                                                   validator.ReturnChoise(
                                                                          validator.GetInput(
                                                                                             $"Выберите приоритет проекта из следующих вариантов, введя номер (по умолчанию - {Status}):" +
                                                                                             statuses +
                                                                                             "\n\nВвод: "
                                                                                            ),
                                                                          Enum.GetValues(typeof(TaskStatus)).Length
                                                                         ),
                                                   Convert.ToString(Array.IndexOf(taskStatuses, Status)),
                                                   "\n"
                                                  )
                                             );

            Status = (TaskStatus)indexPriority;

            DueDate = Convert.ToDateTime(Next(
                                               validator.ReturnSpecial(
                                                                       validator.GetInput($"Срок сдачи до (по умолчанию - {DueDate}): "),
                                                                       CreationDate
                                                                      ),
                                               Convert.ToString(DueDate),
                                               "\n"
                                              )
                                         );

            AssignedTo = Next(
                               validator.Line(validator.GetInput($"Назначено (по умолчанию - {AssignedTo}): ")),
                               AssignedTo,
                               "\n"
                              );

            int actionWithList = validator.Variant(validator.GetInput($"Выберите действие с коментарием, введя номер действия:{actionList}"), 1, 5) - 1;
            
            switch(actionWithList)
            {
                case 0:
                    Comments.Add(validator.Line(validator.GetInput("Комментарий: ")));
                    break;
                case 1:
                    indexComment = validator.Variant(validator.GetInput($"Введи какой по порядку коментарий ты хочешь удалить?: \n{string.Join("\n", _comments)}"), 1, Comments.Count) - 1;
                    Comments.RemoveAt(indexComment);
                    break;
                case 2:
                    indexComment = validator.Variant(validator.GetInput($"Введи какой по порядку коментарий ты хочешь перезаписать?: \n{string.Join("\n", _comments)}"), 1, Comments.Count) - 1;
                    Comments[indexComment] = validator.Line(validator.GetInput("Комментарий: "));
                    break;
                case 3:
                    Comments.Clear();
                    break;
            }
        }

        public override void ViewNote()
        {
            Console.WriteLine($"Создано: {CreationDate}" +
                              $"Название проекта: {ProjectName}" +
                              $"Описание проекта: {TaskDescription}" +
                              $"Приоритет: {Priority}" +
                              $"Статус: {Status}" +
                              $"Срок сдачи до: {DueDate}" +
                              $"Назначено: {AssignedTo}" +
                              $"Комментарий: {Comments}");
        }
    }

    class HomeNote: NoteBook
    {
        private string _taskType;
        private string _description;
        private string _location;
        private FrequencyType _frequencyType;
        private string _assignedTo;
        private List<string> _materials;
        private PriorityLevel _priority;

        public string TaskType
        {
            get
            {
                return _taskType;
            }

            set
            {
                _taskType = value;
            }
        }

        public string Location
        {
            get
            {
                return _location;
            }

            set
            {
                _location = value;
            }
        }

        public FrequencyType FrequencyType
        {
            get
            {
                return _frequencyType;
            }

            set
            {
                _frequencyType = value;
            }
        }

        public string AssignedTo
        {
            get
            {
                return _assignedTo;
            }

            set
            {
                _assignedTo = value;
            }
        }

        public PriorityLevel Priority
        {
            get
            {
                return _priority;
            }

            set
            {
                _priority = value;
            }
        }

        public string Description
        {
            get
            {
                return _description;
            }

            set
            {
                _description = value;
            }
        }

        public override void InfoOutput()
        {
            Console.WriteLine("Дом:" +
                              $"\n{new string(Convert.ToChar("-"), 64)}" +
                              $"\nТип: {_taskType}" +
                              $"\nОписание: {_description}" +
                              $"\nМесто: {_location}" +
                              $"\nЧастота: {_frequencyType}" +
                              $"\nНазначено: {_assignedTo}" +
                              $"\nМатериалы: {_materials}" +
                              $"\nПриоритет: {_priority}"
                             );
        }

        public override void CreateNote()
        {
            
        }

        public override void EditNote()
        {
            
        }

        public override void ViewNote()
        {
            
        }
    }

    class HealthNote: NoteBook
    {
        private string _appointmentType;
        private string _specialist;
        private string _location;
        private string _description;
        private DateTime _time;
        private TimeSpan _duration;
        private AppointmentStatus _status;

        public string AppointmentType
        {
            get
            {
                return _appointmentType;
            }

            set
            {
                _appointmentType = value;
            }
        }

        public string Specialist
        {
            get
            {
                return _specialist;
            }

            set
            {
                _specialist = value;
            }
        }

        public string Location
        {
            get
            {
                return _location;
            }

            set
            {
                _location = value;
            }
        }

        public string Description
        {
            get
            {
                return _description;
            }

            set
            {
                _description = value;
            }
        }

        public DateTime Time
        {
            get
            {
                return _time;
            }

            set
            {
                _time = value;
            }
        }

        public TimeSpan Duration
        {
            get
            {
                return _duration;
            }

            set
            {
                _duration = value;
            }
        }

        public AppointmentStatus Status
        {
            get
            {
                return _status;
            }

            set
            {
                _status = value;
            }
        }

        public override void InfoOutput()
        {
            Console.WriteLine("Здоровье:" +
                              $"\n{new string(Convert.ToChar("-"), 64)}" +
                              $"\nТип: {AppointmentType}" +
                              $"\nСпециалист: {Specialist}" +
                              $"\nМесто: {Location}" +
                              $"\nОписание: {Description}" +
                              $"\nСрок выполнения: {Time}" +
                              $"\nДлительность: {Duration}" +
                              $"\nСтатус: {Status}"
                             );
        }

        public override void CreateNote()
        {
            CreationDate = DateTime.Now.Date;


        }

        public override void EditNote()
        {
            
        }

        public override void ViewNote()
        {
            
        }
    }
}
