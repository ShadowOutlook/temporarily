﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace ConnectDB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //ViewTable();

            //InsertRecordToTable();

            //UpdateRecordToTable();

            //DeleteRecordToTable();

            //CountRecord();

            //MaxScholarship();
        }

        static void ViewTable()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand();
                    command.CommandText = "SELECT * FROM Student";
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            Console.Write((reader[i].ToString()).Trim() + " ");
                        }

                        Console.WriteLine("");
                    }

                    connection.Close();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.Read();
        }

        static void InsertRecordToTable()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

            string sqlSelect = "SELECT * FROM Hobbies";
            string sqlInsert = "INSERT INTO Hobbies (HobbieName) VALUES ('Карате'), ('Программирование')";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand oldSelectCommand = new SqlCommand(sqlSelect, connection);
                    SqlDataReader oldReader = oldSelectCommand.ExecuteReader();

                    while (oldReader.Read())
                    {
                        for (int i = 0; i < oldReader.FieldCount; i++)
                        {
                            Console.Write((oldReader[i].ToString()).Trim() + " ");
                        }

                        Console.WriteLine("");
                    }

                    Console.WriteLine("");

                    oldReader.Close();

                    SqlCommand insertCommand = new SqlCommand(sqlInsert, connection);
                    int number = insertCommand.ExecuteNonQuery();
                    Console.WriteLine($"Обновлено объектов: {number}\n");

                    SqlCommand newSelectCommand = new SqlCommand(sqlSelect, connection);
                    SqlDataReader newReader = newSelectCommand.ExecuteReader();

                    while (newReader.Read())
                    {
                        for (int i = 0; i < newReader.FieldCount; i++)
                        {
                            Console.Write((newReader[i].ToString()).Trim() + " ");
                        }

                        Console.WriteLine("");
                    }

                    connection.Close();
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.Read();
        }

        static void UpdateRecordToTable()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

            string sqlSelect = "SELECT * FROM Hobbies";
            string sqlUpdate = "UPDATE Hobbies SET HobbieName = 'Рыбалка' WHERE HobbieId = 19";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand oldSelectCommand = new SqlCommand(sqlSelect, connection);
                    SqlDataReader oldReader = oldSelectCommand.ExecuteReader();

                    while (oldReader.Read())
                    {
                        for (int i = 0; i < oldReader.FieldCount; i++)
                        {
                            Console.Write((oldReader[i].ToString()).Trim() + " ");
                        }

                        Console.WriteLine("");
                    }

                    Console.WriteLine("");

                    oldReader.Close();

                    SqlCommand updateCommand = new SqlCommand(sqlUpdate, connection);
                    int number = updateCommand.ExecuteNonQuery();
                    Console.WriteLine($"Обновлено объектов: {number}\n");

                    SqlCommand newSelectCommand = new SqlCommand(sqlSelect, connection);
                    SqlDataReader newReader = newSelectCommand.ExecuteReader();

                    while (newReader.Read())
                    {
                        for (int i = 0; i < newReader.FieldCount; i++)
                        {
                            Console.Write((newReader[i].ToString()).Trim() + " ");
                        }

                        Console.WriteLine("");
                    }

                    connection.Close();
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.Read();
        }

        static void DeleteRecordToTable()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

            string sqlSelect = "SELECT * FROM Hobbies";
            string sqlDelete = "DELETE FROM Hobbies WHERE HobbieId = 20";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand oldSelectCommand = new SqlCommand(sqlSelect, connection);
                    SqlDataReader oldReader = oldSelectCommand.ExecuteReader();

                    while (oldReader.Read())
                    {
                        for (int i = 0; i < oldReader.FieldCount; i++)
                        {
                            Console.Write((oldReader[i].ToString()).Trim() + " ");
                        }

                        Console.WriteLine("");
                    }

                    Console.WriteLine("");

                    oldReader.Close();

                    SqlCommand deleteCommand = new SqlCommand(sqlDelete, connection);
                    int number = deleteCommand.ExecuteNonQuery();
                    Console.WriteLine($"Обновлено объектов: {number}\n");

                    SqlCommand newSelectCommand = new SqlCommand(sqlSelect, connection);
                    SqlDataReader newReader = newSelectCommand.ExecuteReader();

                    while (newReader.Read())
                    {
                        for (int i = 0; i < newReader.FieldCount; i++)
                        {
                            Console.Write((newReader[i].ToString()).Trim() + " ");
                        }

                        Console.WriteLine("");
                    }

                    connection.Close();
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.Read();
        }

        static void CountRecord()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

            string sqlCount = "SELECT Count(*) FROM Student";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand countRecord = new SqlCommand(sqlCount, connection);
                    object count = countRecord.ExecuteScalar();

                    Console.WriteLine($"Количество записей в таблице Student: {count}\n");

                    ViewTable();

                    connection.Close();
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.Read();
        }

        static void MaxScholarship()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

            string sqlStudent = "SELECT StudentSurname + ' ' + StudentName + ' ' + StudentPatronymic AS ФИО FROM Student WHERE Scholarship = (SELECT MAX(Scholarship) FROM Student)";
            string sqlMax = "SELECT MAX(Scholarship) FROM Student";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand maxScholarship = new SqlCommand(sqlMax, connection);
                    SqlCommand studentInfo = new SqlCommand(sqlStudent, connection);

                    object max = maxScholarship.ExecuteScalar();
                    object student = studentInfo.ExecuteScalar();

                    Console.WriteLine($"Максимальную стипендию имеет студент: {student} со стипендией - {max}\n");

                    ViewTable();
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.Read();
        }
    }
}
