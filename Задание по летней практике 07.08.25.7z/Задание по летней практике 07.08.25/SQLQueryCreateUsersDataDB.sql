USE [master]
GO

CREATE DATABASE UsersDataDB;
GO

CREATE TABLE UsersData (
	UserId INT IDENTITY(1,1),
	Surname NVARCHAR(50),
	[Name] NVARCHAR(50),
	Patronymic NVARCHAR(50),
	Email NVARCHAR(255),
	CountryCode NVARCHAR(10),
	AreaCode NVARCHAR(10),
	PhoneNumber NVARCHAR(25),
	UserName NVARCHAR(100),
	PasswordHash NVARCHAR(512),
	Salt NVARCHAR(64),
	CreatedAt DATETIME,

	CONSTRAINT PK_UsersData_UserId PRIMARY KEY(UserId),
	CONSTRAINT UQ_UsersData_Email UNIQUE(Email),
	CONSTRAINT UQ_UsersData_PhoneNumber UNIQUE(PhoneNumber),
	CONSTRAINT UQ_UsersData_UserName UNIQUE(UserName)
);
GO

CREATE TABLE UsersLog (
	LogId INT IDENTITY(1,1),
	UserId INT,
	[Action] NVARCHAR(50),

	CONSTRAINT PK_UsersLog_LogId PRIMARY KEY(LogId),
	CONSTRAINT FK_UsersLog_UserId FOREIGN KEY(UserId) REFERENCES UsersData(UserId) ON DELETE CASCADE ON UPDATE CASCADE
);
GO

CREATE TABLE UsersDataTrash (
	UserId INT IDENTITY(1,1),
	Surname NVARCHAR(50),
	[Name] NVARCHAR(50),
	Patronymic NVARCHAR(50),
	Email NVARCHAR(255),
	CountryCode NVARCHAR(10),
	AreaCode NVARCHAR(10),
	PhoneNumber NVARCHAR(25),
	UserName NVARCHAR(100),
	PasswordHash NVARCHAR(512),
	Salt NVARCHAR(64),
	CreatedAt DATETIME,
	DeletedAt DATETIME,

	CONSTRAINT PK_UsersData_UserId PRIMARY KEY(UserId),
	CONSTRAINT UQ_UsersData_Email UNIQUE(Email),
	CONSTRAINT UQ_UsersData_PhoneNumber UNIQUE(PhoneNumber),
	CONSTRAINT UQ_UsersData_UserName UNIQUE(UserName)
);
GO