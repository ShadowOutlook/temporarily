USE [UsersDataDB]
GO

CREATE PROCEDURE DeleteUserDataById
	@UserId INT
AS
BEGIN 
	SET NOCOUNT ON;

	INSERT INTO UsersDataTrash (
		Surname,
		[Name],
		Patronymic,
		Email,
		CountryCode,
		AreaCode,
		PhoneNumber,
		UserName,
		PasswordHash,
		Salt,
		CreatedAt,
		DeletedAt
	)
	SELECT
		Surname,
		[Name],
		Patronymic,
		Email,
		CountryCode,
		AreaCode,
		PhoneNumber,
		UserName,
		PasswordHash,
		Salt,
		CreatedAt,
		GETDATE()
	FROM UsersData
	WHERE UserId = @UserId;

	DELETE FROM UsersData WHERE UserId = @UserId;
END;
GO