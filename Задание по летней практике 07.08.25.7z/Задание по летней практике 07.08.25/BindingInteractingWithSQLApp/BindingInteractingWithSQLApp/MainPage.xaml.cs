﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BindingInteractingWithSQLApp
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();

            string[] placeholderArray = {"Имя пользователя, номер телефона или Email", "Пароль"};

            tbxLogin.Tag = placeholderArray[0];
            pbxPassword.Tag = placeholderArray[1];
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {

        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            var pb = sender as PasswordBox;
            if (pb != null)
            {
                pb.Tag = !string.IsNullOrEmpty(pb.Password);
            }
        }
    }
}
