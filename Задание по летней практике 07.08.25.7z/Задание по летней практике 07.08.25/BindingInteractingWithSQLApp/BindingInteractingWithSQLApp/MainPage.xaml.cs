﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BindingInteractingWithSQLApp
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();

            string[] placeholderArray = {"Имя пользователя или Email", "Пароль"};

            LoginPlaceholder.Content = placeholderArray[0];
            PasswordPlaceholder.Content = placeholderArray[1];
        }

        private void tbxLoginMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (tbxLogin.Text == "")
            {
                LoginPlaceholder.Visibility = Visibility.Visible;
            }
            else
            {
                LoginPlaceholder.Visibility = Visibility.Hidden;
            }
        }

        private void tbxLoginTextChanged(object sender, TextChangedEventArgs e)
        {
            if (tbxLogin.Text == "")
            {
                LoginPlaceholder.Visibility = Visibility.Visible;
            }
            else
            {
                LoginPlaceholder.Visibility = Visibility.Hidden;
            }
        }

        private void tbxLoginGotFocus(object sender, RoutedEventArgs e)
        {
            LoginPlaceholder.Visibility = Visibility.Hidden;
        }

        private void tbxLoginLostFocus(object sender, RoutedEventArgs e)
        {
            if (tbxLogin.Text == "")
            {
                LoginPlaceholder.Visibility = Visibility.Visible;
            }
        }

        private void pbxPasswordMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (pbxPassword.Password == "")
            {
                PasswordPlaceholder.Visibility = Visibility.Visible;
            }
            else
            {
                PasswordPlaceholder.Visibility = Visibility.Hidden;
            }
        }   

        private void pbxPasswordChanged(object sender, RoutedEventArgs e)
        {
            if (pbxPassword.Password == "")
            {
                PasswordPlaceholder.Visibility = Visibility.Visible;
            }
            else
            {
                PasswordPlaceholder.Visibility = Visibility.Hidden;
            }
        }

        private void pbxPasswordGotFocus(object sender, RoutedEventArgs e)
        {
            PasswordPlaceholder.Visibility = Visibility.Hidden;
        }

        private void pbxPasswordLostFocus(object sender, RoutedEventArgs e)
        {
            LoginPlaceholder.Visibility = Visibility.Visible;
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
