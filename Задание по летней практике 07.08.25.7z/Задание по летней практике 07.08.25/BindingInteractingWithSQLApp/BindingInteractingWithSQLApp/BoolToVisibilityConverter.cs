﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows;

namespace BindingInteractingWithSQLApp
{
    public class BoolToVisibilityConverter : IMultiValueConverter

    {

        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values == null || values.Length < 2)
                return Visibility.Visible;

            if (values[0] == DependencyProperty.UnsetValue || values[1] == DependencyProperty.UnsetValue)
                return Visibility.Visible;

            bool hasText = false;
            bool hasFocus = false;

            if (values[0] is bool textBool)
                hasText = !textBool;

            if (values[1] is bool focusBool)
                hasFocus = focusBool;

            if (hasText || hasFocus)
                return Visibility.Collapsed;

            return Visibility.Visible;
        }


        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
