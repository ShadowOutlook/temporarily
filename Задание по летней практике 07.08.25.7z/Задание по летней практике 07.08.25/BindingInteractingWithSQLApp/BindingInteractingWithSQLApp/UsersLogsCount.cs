﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BindingInteractingWithSQLApp
{
    public class UsersLogsCount
    {
        public int LogId { get; set; }
        
        public int UserId { get; set; }
        
        public int ActionsCount { get; set; }
    }
}
