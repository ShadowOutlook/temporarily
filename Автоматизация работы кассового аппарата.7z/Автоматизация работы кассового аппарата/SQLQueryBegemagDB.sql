USE [master]
GO

CREATE DATABASE BegemagDB;
GO

USE BegemagDB;
GO

CREATE TABLE CompanyInfo (
	CompanyId INT IDENTITY(1,1),

	CompanyName NVARCHAR(50)NOT NULL,
	INN INT NOT NULL,
	SiteFNS NVARCHAR(50) NOT NULL,
	Email NVARCHAR(50) NOT NULL,

	CONSTRAINT PK_CompanyInfo_CompanyId PRIMARY KEY(CompanyId),
	CONSTRAINT UQ_CompanyInfo_CompanyName UNIQUE(CompanyName),
	CONSTRAINT UQ_CompanyInfo_INN UNIQUE(INN),
	CONSTRAINT UQ_CompanyInfo_Email UNIQUE(Email)
);
GO

CREATE TABLE Payment (
	PaymentId INT IDENTITY(1,1),

	PaymentType NVARCHAR(50),

	CONSTRAINT PK_Payment_PaymentId PRIMARY KEY(PaymentId),
	CONSTRAINT UQ_Payment_PaymentType UNIQUE(PaymentType)
);
GO

CREATE TABLE Customer (
	CustomerId INT IDENTITY(1,1),

	CustomerName NVARCHAR(50) NOT NULL,
	PhoneNumber INT NOT NULL,
	Email NVARCHAR(250) NULL,

	CONSTRAINT PK_Customer_CustomerId PRIMARY KEY(CustomerId),
	CONSTRAINT UQ_Customer_PhoneNumber UNIQUE(PhoneNumber),
	CONSTRAINT UQ_Customer_Email UNIQUE(Email)
);
GO

CREATE TABLE BonusAccrualRule (
    BonusAccrualRuleId INT IDENTITY(1,1),

    RuleName NVARCHAR(50) NOT NULL,
    AccrualPercentage INT NOT NULL,

	CONSTRAINT PK_BonusAccrualRule_RuleId PRIMARY KEY(BonusAccrualRuleId),
	CONSTRAINT UQ_BonusAccrualRule_RuleName UNIQUE(RuleName)
);
GO

CREATE TABLE BonusCard (
	BonusCardId INT IDENTITY(1,1),
	PaymentId INT NOT NULL,
	CustomerId INT NULL,
	BonusAccrualRuleId INT NOT NULL DEFAULT (1),

	BonusCardNumber NVARCHAR(50) NOT NULL,
	BonusCardAmmount INT NOT NULL, -- ����������� ��� ������ �������������, !!�� �������!!

	CONSTRAINT PK_BonusCard_BonusCardId PRIMARY KEY(BonusCardId),
	CONSTRAINT FK_BonusCard_PaymentId FOREIGN KEY(PaymentId) REFERENCES Payment(PaymentId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT FK_BonusCard_CustomerId FOREIGN KEY(CustomerId) REFERENCES Customer(CustomerId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT FK_BounsCard_BonusAccrualRuleId FOREIGN KEY(BonusAccrualRuleId) REFERENCES BonusAccrualRule(BonusAccrualRuleId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT UQ_BonusCard_BonusCardNumber UNIQUE(BonusCardNumber),
	CONSTRAINT UQ_BonusCard_CustomerId UNIQUE(CustomerId)
);
GO

CREATE TABLE Position (
	PositionId INT IDENTITY(1,1),

	PositionName NVARCHAR(100) NOT NULL,
	Salary INT NOT NULL,

	CONSTRAINT PK_Position_PositionId PRIMARY KEY(PositionId),
	CONSTRAINT UQ_Position_PositionName UNIQUE(PositionName)
);
GO

CREATE TABLE CategoryProduct (
	CategoryProductId INT IDENTITY(1,1),

	CategoryProduct NVARCHAR(50) NOT NULL,
	VATAmount INT NOT NULL,

	CONSTRAINT PK_CategoryProduct_CategoryProductId PRIMARY KEY(CategoryProductId),
	CONSTRAINT UQ_CategoryProduct_CategoryProduct UNIQUE(CategoryProduct)
);
GO

CREATE TABLE [Product] (
	ProductId INT IDENTITY(1,1),
	CategoryProductId INT NOT NULL,

	ProductName NVARCHAR(200) NOT NULL,
	PrePrice FLOAT NOT NULL,

	CONSTRAINT PK_Product_ProductId PRIMARY KEY(ProductId),
	CONSTRAINT FK_Product_CategoryProductId FOREIGN KEY(CategoryProductId) REFERENCES CategoryProduct(CategoryProductId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT UQ_Product_ProductName UNIQUE(ProductName)
);
GO

CREATE TABLE DocumentType (
	DocumentTypeId INT IDENTITY(1,1),

	DocumentType NVARCHAR(50) NOT NULL,

	CONSTRAINT PK_DocumentType_DocumentTypeId PRIMARY KEY(DocumentTypeId),
	CONSTRAINT UQ_DocumentType_DocumentType UNIQUE(DocumentType)
);
GO

CREATE TABLE Market (
	MarketId INT IDENTITY(1,1),

	MarketName NVARCHAR(50) NOT NULL,

	CONSTRAINT PK_Market_MarketId PRIMARY KEY(MarketId),
	CONSTRAINT UQ_Market_MarketName UNIQUE(MarketName)
);
GO

CREATE TABLE City (
	CityId INT IDENTITY(1,1),

	CityName NVARCHAR(100) NOT NULL,

	CONSTRAINT PK_City_CityId PRIMARY KEY(CityId),
	CONSTRAINT UQ_City_CityName UNIQUE(CityName)
);
GO

CREATE TABLE [Address] (
	MailIndex INT NOT NULL,
	CityId INT NOT NULL,

	[Address] NVARCHAR(250) NOT NULL,

	CONSTRAINT PK_Address_MailIndex PRIMARY KEY(MailIndex),
	CONSTRAINT FK_Address_CityId FOREIGN KEY(CityId) REFERENCES City(CityId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT UQ_Address_Address UNIQUE([Address])
);
GO

CREATE TABLE TraidingPoint (
	TraidingPointId INT IDENTITY(1,1),
	MarketId INT NULL,
	MailIndex INT NOT NULL,

	CONSTRAINT PK_TraidingPoint_TraidingPointId PRIMARY KEY(TraidingPointId),
	CONSTRAINT FK_TraidingPoint_MarketId FOREIGN KEY(MarketId) REFERENCES Market(MarketId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT FK_TraidingPoint_MailIndex FOREIGN KEY(MailIndex) REFERENCES [Address](MailIndex) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT UQ_TraidingPoint_MailIndex UNIQUE(MailIndex)
);
GO

CREATE TABLE TraidingPointStock (
	StockId INT IDENTITY(1,1),
	ProductId INT NOT NULL,
	TraidingPointId INT NOT NULL,

	ProductCount FLOAT NOT NULL,

	CONSTRAINT PK_TraidingPointStock_StockId PRIMARY KEY(StockId),
	CONSTRAINT FK_TraidingPointStock_ProductId FOREIGN KEY(ProductId) REFERENCES [Product](ProductId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT FK_TraidingPointStock_TraidingPointId FOREIGN KEY(TraidingPointId) REFERENCES TraidingPoint(TraidingPointId) ON DELETE NO ACTION ON UPDATE CASCADE
);
GO

CREATE TABLE Warehouse (
	WarehouseId INT IDENTITY(1,1),

	WarehouseName NVARCHAR(200) NULL,
	MailIndex INT NOT NULL,

	CONSTRAINT PK_Warehouse_WarehouseId PRIMARY KEY(WarehouseId),
	CONSTRAINT FK_Warehouse_MailIndex FOREIGN KEY(MailIndex) REFERENCES [Address](MailIndex) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT UQ_Warehouse_MailIndex UNIQUE(MailIndex)
);
GO

CREATE TABLE WarehouseStock (
	StockId INT IDENTITY(1,1),
	ProductId INT NOT NULL,
	WarehouseId INT NOT NULL,

	ProductCount FLOAT NOT NULL,

	CONSTRAINT PK_WarehouseStock_StockId PRIMARY KEY(StockId),
	CONSTRAINT FK_WarehouseStock_ProductId FOREIGN KEY(ProductId) REFERENCES [Product](ProductId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT FK_WarehouseStock_WarehouseId FOREIGN KEY(WarehouseId) REFERENCES Warehouse(WarehouseId) ON DELETE NO ACTION ON UPDATE CASCADE
);
GO

CREATE TABLE Cashier (
	CashierId INT IDENTITY(1,1),
	TraidingPointId INT NULL,

	FactoryNumberKKT INT NOT NULL,

	CONSTRAINT PK_Cashier_CashierId PRIMARY KEY(CashierId),
	CONSTRAINT FK_Cashier_TraidingPointId FOREIGN KEY(TraidingPointId) REFERENCES TraidingPoint(TraidingPointId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT UQ_Cashier_FactoryNumberKKT UNIQUE(FactoryNumberKKT)
);
GO

CREATE TABLE Employee (
	EmployeeId INT IDENTITY(1,1),
	PositionId INT NULL,
	TraidingPointId INT NULL,

	EmployeeName NVARCHAR(50) NOT NULL,
	EmployeeSurname NVARCHAR(50) NOT NULL,
	EmployeePatronymic NVARCHAR(50) NULL,
	PhoneNumber NVARCHAR(50) NOT NULL,
	Email NVARCHAR(50) NULL,

	CONSTRAINT PK_Employee_EmployeeId PRIMARY KEY(EmployeeId),
	CONSTRAINT FK_Employee_PositionId FOREIGN KEY(PositionId) REFERENCES Position(PositionId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT FK_Employee_TraidingPointId FOREIGN KEY(TraidingPointId) REFERENCES TraidingPoint(TraidingPointId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT UQ_Employee_PhoneNumber UNIQUE(PhoneNumber),
	CONSTRAINT UQ_Employee_Email UNIQUE(Email)
);
GO

CREATE TABLE Discount (
	DiscountId INT IDENTITY(1,1),

	DiscountAmount INT NOT NULL,

	CONSTRAINT PK_Discount_DiscountId PRIMARY KEY(DiscountId),
	CONSTRAINT UQ_Discount_DiscountAmount UNIQUE(DiscountAmount)
);
GO

CREATE TABLE [Shift] (
    ShiftId INT IDENTITY(1,1),
    CashierId INT NOT NULL,
	CashierManId INT NULL,

	ShiftNumber INT NOT NULL,
    StartTime DATETIME NOT NULL DEFAULT GETDATE(),
    EndTime DATETIME NULL,

	MailIndexTimeOfSale INT NOT NULL,
	FactoryNumberKKTTimeOfSale INT NOT NULL,

	CONSTRAINT PK_Shift_ShiftId PRIMARY KEY(ShiftId),
    CONSTRAINT FK_Shift_CashierId FOREIGN KEY (CashierId) REFERENCES Cashier(CashierId) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_Shift_CashierManId FOREIGN KEY (CashierManId) REFERENCES Employee(EmployeeId) ON DELETE NO ACTION ON UPDATE NO ACTION
);

CREATE TABLE CheckDocument (
	CheckDocumentId INT IDENTITY(1,1),
	DocumentTypeId INT NOT NULL,
	PaymentId INT NULL,
	BonusCardId INT NULL,
	CompanyId INT NULL,
	ShiftId INT NOT NULL,

	DocumentTypeTimeOfSale NVARCHAR(50) NOT NULL,
	PaymentTypeTimeOfSale NVARCHAR(50) NOT NULL,

	IsPaymentSuccessful BIT NOT NULL DEFAULT 1,
	CheckDateTime DATETIME NOT NULL,

	CONSTRAINT PK_CheckDocument_CheckDocumentId PRIMARY KEY(CheckDocumentId),
	CONSTRAINT FK_CheckDocument_DocumentTypeId FOREIGN KEY(DocumentTypeId) REFERENCES DocumentType(DocumentTypeId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT FK_CheckDocument_PaymentId FOREIGN KEY(PaymentId) REFERENCES Payment(PaymentId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT FK_CheckDocument_BonusCardId FOREIGN KEY(BonusCardId) REFERENCES BonusCard(BonusCardId) ON DELETE NO ACTION ON UPDATE NO ACTION,
	CONSTRAINT FK_CheckDocument_CompanyId FOREIGN KEY(CompanyId) REFERENCES CompanyInfo(CompanyId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT FK_CheckDocument_ShiftId FOREIGN KEY(ShiftId) REFERENCES [Shift](ShiftId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT UQ_CheckDocument_ShiftId UNIQUE(ShiftId)
);
GO

CREATE TABLE CheckItem (
	CheckItemId INT IDENTITY(1,1),
	CheckDocumentId INT NOT NULL,
	ProductId INT NOT NULL,
	DiscountId INT NULL,
	ProductCount FLOAT NOT NULL,

	ProductNameTimeOfSale NVARCHAR(200) NOT NULL,
	PrePriceTimeOfSale FLOAT NOT NULL,
	VATAmountTimeOfSale INT NOT NULL,
	DiscountAmountTimeOfSale INT NULL,

	CONSTRAINT PK_CheckItem_CheckItemId PRIMARY KEY(CheckItemId),
	CONSTRAINT FK_CheckItem_CheckDocumentId FOREIGN KEY(CheckDocumentId) REFERENCES CheckDocument(CheckDocumentId) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT FK_CheckItem_ProductId FOREIGN KEY(ProductId) REFERENCES [Product](ProductId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT FK_CheckItem_DiscountId FOREIGN KEY(DiscountId) REFERENCES Discount(DiscountId) ON DELETE NO ACTION ON UPDATE CASCADE
);
GO

CREATE TABLE UserActionLog (
    LogId INT IDENTITY PRIMARY KEY,
    CheckDocumentId INT NULL,
	ShiftId INT NOT NULL,

    UserAction NVARCHAR(255) NOT NULL,
    ActionTime DATETIME NOT NULL DEFAULT GETDATE(),

    CONSTRAINT FK_UserActionLog_CheckDocumentId FOREIGN KEY(CheckDocumentId) REFERENCES CheckDocument(CheckDocumentId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT FK_UserActionLog_ShiftId FOREIGN KEY(ShiftId) REFERENCES [Shift](ShiftId) ON DELETE NO ACTION ON UPDATE NO ACTION
);
GO