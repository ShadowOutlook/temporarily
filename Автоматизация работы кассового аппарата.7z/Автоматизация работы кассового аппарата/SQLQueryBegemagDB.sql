USE [master]
GO

CREATE DATABASE BegemagDB;
GO

USE BegemagDB;
GO

CREATE TABLE CompanyInfo (
	CompanyId INT IDENTITY(1,1),
	CompanyName NVARCHAR(50)NOT NULL,
	INN INT NOT NULL,
	SiteFNS NVARCHAR(50) NOT NULL,
	Email NVARCHAR(50) NOT NULL,
	CONSTRAINT PK_CompanyInfo_CompanyId PRIMARY KEY(CompanyId),
	CONSTRAINT UQ_CompanyInfo_CompanyName UNIQUE(CompanyName),
	CONSTRAINT UQ_CompanyInfo_INN UNIQUE(INN),
	CONSTRAINT UQ_CompanyInfo_SiteFNS UNIQUE(SiteFNS),
	CONSTRAINT UQ_CompanyInfo_Email UNIQUE(Email)
);
GO

CREATE TABLE Payment (
	PaymentId INT IDENTITY(1,1),
	PaymentType NVARCHAR(50),
	CONSTRAINT PK_Payment_PaymentId PRIMARY KEY(PaymentId),
	CONSTRAINT UQ_Payment_PaymentType UNIQUE(PaymentType)
);
GO

CREATE TABLE Customer (
	CustomerId INT IDENTITY(1,1),
	CustomerName NVARCHAR(50) NOT NULL,
	PhoneNumber INT NOT NULL,
	CONSTRAINT PK_Customer_CustomerId PRIMARY KEY(CustomerId),
	CONSTRAINT UQ_Customer_PhoneNumber UNIQUE(PhoneNumber)
);
GO

CREATE TABLE BonusCard (
	BonusCardId INT IDENTITY(1,1),
	PaymentId INT NOT NULL,
	CustomerId INT NULL,
	BonusCardNumber NVARCHAR(50) NOT NULL,
	BonusCardAmmount INT NOT NULL,
	CONSTRAINT PK_BonusCard_BonusCardId PRIMARY KEY(BonusCardId),
	CONSTRAINT FK_BonusCard_PaymentId FOREIGN KEY(PaymentId) REFERENCES Payment(PaymentId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT FK_BonusCard_CustomerId FOREIGN KEY(CustomerId) REFERENCES Customer(CustomerId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT UQ_BonusCard_BonusCardNumber UNIQUE(BonusCardNumber),
	CONSTRAINT UQ_BonusCard_CustomerId UNIQUE(CustomerId)
);
GO

CREATE TABLE Position (
	PositionId INT IDENTITY(1,1),
	PositionName NVARCHAR(100) NOT NULL,
	Salary INT NOT NULL,
	CONSTRAINT PK_Position_PositionId PRIMARY KEY(PositionId),
	CONSTRAINT UQ_Position_PositionName UNIQUE(PositionName)
);
GO

CREATE TABLE CategoryProduct (
	CategoryProductId INT IDENTITY(1,1),
	CategoryProduct NVARCHAR(50) NOT NULL,
	VATAmount INT NOT NULL,
	CONSTRAINT PK_CategoryProduct_CategoryProductId PRIMARY KEY(CategoryProductId),
	CONSTRAINT UQ_CategoryProduct_CategoryProduct UNIQUE(CategoryProduct)
);
GO

CREATE TABLE Product (
	ProductId INT IDENTITY(1,1),
	CategoryProductId INT NULL,
	ProductName NVARCHAR(100) NOT NULL,
	PrePrice INT NOT NULL,
	BasePrice INT NOT NULL,
	CONSTRAINT PK_Product_ProductId PRIMARY KEY(ProductId),
	CONSTRAINT FK_CategoryProduct_CategoryProductId FOREIGN KEY(CategoryProductId) REFERENCES CategoryProduct(CategoryProductId) ON DELETE SET NULL ON UPDATE CASCADE
);
GO

CREATE TABLE DocumentType (
	DocumentTypeId INT IDENTITY(1,1),
	DocumentType NVARCHAR(50) NOT NULL,
	CONSTRAINT PK_DocumentType_DocumentTypeId PRIMARY KEY(DocumentTypeId),
	CONSTRAINT UQ_DocumentType_DocumentType UNIQUE(DocumentType)
);
GO

CREATE TABLE Market (
	MarketId INT IDENTITY(1,1),
	MarketName NVARCHAR(50) NOT NULL,
	CONSTRAINT PK_Market_MarketId PRIMARY KEY(MarketId),
	CONSTRAINT UQ_Market_MarketName UNIQUE(MarketName)
);
GO

CREATE TABLE TraidingCity (
	CityId INT IDENTITY(1,1),
	CityName INT NOT NULL,
	CONSTRAINT PK_TraidingCity_CityId PRIMARY KEY(CityId),
	CONSTRAINT UQ_TraidingCity_CityName UNIQUE(CityName)
);
GO

CREATE TABLE TraidingAddress (
	MailIndex INT NOT NULL,
	CityId INT NOT NULL,
	TraidingAddress NVARCHAR(100) NOT NULL,
	CONSTRAINT PK_TraidingAddress_MailIndex PRIMARY KEY(MailIndex),
	CONSTRAINT FK_TraidingAddress_CityId FOREIGN KEY(CityId) REFERENCES TraidingCity(CityId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT UQ_TraidingAddress_TraidingAddress UNIQUE(TraidingAddress)
);
GO

CREATE TABLE TraidingPoint (
	TraidingPointId INT IDENTITY(1,1),
	MarketId INT NULL,
	MailIndex INT NOT NULL,
	CONSTRAINT PK_TraidingPoint_TraidingPointId PRIMARY KEY(TraidingPointId),
	CONSTRAINT FK_TraidingPoint_MarketId FOREIGN KEY(MarketId) REFERENCES Market(MarketId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT FK_TraidingPoint_MailIndex FOREIGN KEY(MailIndex) REFERENCES TraidingAddress(MailIndex) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT UQ_TraidingPoint_TraidingAddressId UNIQUE(MailIndex)
);
GO

CREATE TABLE TraidingPointStock (
	StockId INT IDENTITY(1,1),
	ProductId INT NOT NULL,
	TraidingPointId INT NOT NULL,
	ProductCount INT NOT NULL,
	CONSTRAINT PK_TraidingPointStock_StockId PRIMARY KEY(StockId),
	CONSTRAINT FK_TraidingPointStock_ProductId FOREIGN KEY(ProductId) REFERENCES Product(ProductId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT FK_TraidingPointStock_TraidingPointId FOREIGN KEY(TraidingPointId) REFERENCES TraidingPoint(TraidingPointId) ON DELETE NO ACTION ON UPDATE CASCADE
);
GO

CREATE TABLE WarehouseCity (
	CityId INT IDENTITY(1,1),
	CityName INT NOT NULL,
	CONSTRAINT PK_WarehouseCity_CityId PRIMARY KEY(CityId),
	CONSTRAINT UQ_WarehouseCity_CityName UNIQUE(CityName)
);
GO

CREATE TABLE WarehouseAddress (
	MailIndex INT NOT NULL,
	CityId INT NOT NULL,
	WarehouseAddress NVARCHAR(100) NOT NULL,
	CONSTRAINT PK_WarehouseAddress_MailIndex PRIMARY KEY(MailIndex),
	CONSTRAINT FK_WarehouseAddress_CityId FOREIGN KEY(CityId) REFERENCES WarehouseCity(CityId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT UQ_WarehouseAddress_WarehouseAddress UNIQUE(WarehouseAddress)
);
GO

CREATE TABLE Warehouse (
	WarehouseId INT IDENTITY(1,1),
	MailIndex INT NOT NULL,
	CONSTRAINT PK_Warehouse_WarehouseId PRIMARY KEY(WarehouseId),
	CONSTRAINT FK_Warehouse_MailIndex FOREIGN KEY(MailIndex) REFERENCES WarehouseAddress(MailIndex) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT UQ_Warehouse_WarehouseId UNIQUE(WarehouseId)
);
GO

CREATE TABLE WarehouseStock (
	StockId INT IDENTITY(1,1),
	ProductId INT NOT NULL,
	WarehouseId INT NOT NULL,
	ProductCount INT NOT NULL,
	CONSTRAINT PK_WarehouseStock_StockId PRIMARY KEY(StockId),
	CONSTRAINT FK_WarehouseStock_ProductId FOREIGN KEY(ProductId) REFERENCES Product(ProductId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT FK_WarehouseStock_WarehouseId FOREIGN KEY(WarehouseId) REFERENCES Warehouse(WarehouseId) ON DELETE NO ACTION ON UPDATE CASCADE
);
GO

CREATE TABLE Cashier (
	CashierId INT IDENTITY(1,1),
	TraidingPointId INT NULL,
	FactoryNumberKKT INT NOT NULL,
	CONSTRAINT PK_Cashier_CashierId PRIMARY KEY(CashierId),
	CONSTRAINT FK_Cashier_TraidingPointId FOREIGN KEY(TraidingPointId) REFERENCES TraidingPoint(TraidingPointId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT UQ_Cashier_FactoryNumberKKT UNIQUE(FactoryNumberKKT)
);
GO

CREATE TABLE Employee (
	EmployeeId INT IDENTITY(1,1),
	PositionId INT NULL,
	TraidingPointId INT NULL,
	EmployeeName NVARCHAR(50) NOT NULL,
	EmployeeSurname NVARCHAR(50) NOT NULL,
	EmployeePatronymic NVARCHAR(50) NULL,
	PhoneNumber NVARCHAR(50) NOT NULL,
	Email NVARCHAR(50) NULL,
	CONSTRAINT PK_Employee_EmployeeId PRIMARY KEY(EmployeeId),
	CONSTRAINT FK_Employee_PositionId FOREIGN KEY(PositionId) REFERENCES Position(PositionId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT FK_Employee_TraidingPointId FOREIGN KEY(TraidingPointId) REFERENCES TraidingPoint(TraidingPointId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT UQ_Employee_PhoneNumber UNIQUE(PhoneNumber),
	CONSTRAINT UQ_Employee_Email UNIQUE(Email)
);
GO

CREATE TABLE Discount (
	DiscountId INT IDENTITY(1,1),
	DiscountAmount INT NOT NULL,
	CONSTRAINT PK_Discount_DiscountId PRIMARY KEY(DiscountId),
	CONSTRAINT UQ_Discount_DiscountAmount UNIQUE(DiscountAmount)
);
GO

CREATE TABLE CheckDocument (
	CheckId INT IDENTITY(1,1),
	CashierId INT NOT NULL,
	CashierManId INT NULL,
	DocumentTypeId INT NOT NULL,
	PaymentId INT NULL,
	CompanyId INT NULL,
	Shift INT NOT NULL,
	PreAmount INT NOT NULL,
	TotalDiscount INT NOT NULL,
	TotalAmount INT NOT NULL,
	CashChange INT NOT NULL,
	CheckDateTime DATETIME NOT NULL,
	FactoryNumberKKT INT NOT NULL,
	CONSTRAINT PK_CheckDocument_CheckId PRIMARY KEY(CheckId),
	CONSTRAINT FK_CheckDocument_CashierId FOREIGN KEY(CashierId) REFERENCES Cashier(CashierId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT FK_CheckDocument_CashierManId FOREIGN KEY(CashierManId) REFERENCES Employee(EmployeeId) ON DELETE NO ACTION ON UPDATE NO ACTION,
	CONSTRAINT FK_CheckDocument_DocumentTypeId FOREIGN KEY(DocumentTypeId) REFERENCES DocumentType(DocumentTypeId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT FK_CheckDocument_PaymentId FOREIGN KEY(PaymentId) REFERENCES Payment(PaymentId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT FK_CheckDocument_CompanyId FOREIGN KEY(CompanyId) REFERENCES CompanyInfo(CompanyId) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT UQ_CheckDoucment_FactoryNumberKKT UNIQUE(FactoryNumberKKT)
);
GO

CREATE TABLE CheckItem (
	ItemId INT IDENTITY(1,1),
	CheckId INT NOT NULL,
	ProductId INT NOT NULL,
	DiscountId INT NOT NULL,
	ProductCount INT NOT NULL,
	VATAmount INT NOT NULL,
	DiscountAmount INT NOT NULL,
	FinalPrice INT NOT NULL,
	CONSTRAINT PK_CheckItem_ItemId PRIMARY KEY(ItemId),
	CONSTRAINT FK_CheckItem_CheckId FOREIGN KEY(CheckId) REFERENCES CheckDocument(CheckId) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT FK_CheckItem_ProductId FOREIGN KEY(ProductId) REFERENCES Product(ProductId) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT FK_CheckItem_DiscountId FOREIGN KEY(DiscountId) REFERENCES Discount(DiscountId) ON DELETE NO ACTION ON UPDATE CASCADE
);
GO