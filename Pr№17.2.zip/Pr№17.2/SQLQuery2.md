
| `C:\Program Files\Microsoft SQL Server\...IAb221_SabirovU_log.ldf` | `Безопасность/Дополнительно/Добавить/Полный доступ(пользователь: H-WAY-SBR/sabir)` |
| ------------------------------------------------------------------ | ---------------------------------------------------------------------------------- |
| `cmd` - `Admininstrator`                                           | `net stop MSSQLSERVER`                                                             |
| `HexEd.it`                                                         | `C:\Program Files\Microsoft SQL Server\...IAb221_SabirovU_log.ldf`                 |
