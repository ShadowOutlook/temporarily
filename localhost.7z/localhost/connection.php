<?php
    function FormatErrors( $errors ) {
        
        echo "Error information: <br/>";
        
        foreach ( $errors as $error ){
            
            echo "SQLSTATE: ".$error['SQLSTATE']."<br/>";
            echo "Code: ".$error['code']."<br/>";
            echo "Message: ".$error['message']."<br/>";
        }

    }

    $serverName = "H-WAY-SBR";

    $conn = sqlsrv_connect( $serverName);

    if ($conn){
        echo "Соединение успешно установлено!";
    }
    else{
        echo "Ошибка соединения.";
        FormatErrors(sqlsrv_errors());
    }
?>