<?php
function FormatErrors( $errors )

{

echo "Error information: <br/>";



foreach ( $errors as $error )

{

echo "SQLSTATE: ".$error['SQLSTATE']."<br/>";

echo "Code: ".$error['code']."<br/>";

echo "Message: ".$error['message']."<br/>";

}

}



$serverName = "H-WAY-SBR";



$conn = sqlsrv_connect( $serverName);

if( $conn === false )

{ die( FormatErrors(sqlsrv_errors()) ); }



var_dump($conn);
?>