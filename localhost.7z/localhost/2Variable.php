<?php
$lable = "2Variable";
$message = "Hello World!";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title><?= htmlspecialchars($lable) ?></title>
        <link rel="stylesheet" type="text/css" href="styles.css"/>
    </head>
    <body>
        <div class="grid-container-base" style="--cols: 20fr 60fr 20fr; --rows: 20fr 60fr 20fr;">
            <div class="base-border center-2x2">
                <p class="main-text" style="font-size: 32px"><?= htmlspecialchars($message) ?></p>
            </div>
        </div>
    </body>
</html>