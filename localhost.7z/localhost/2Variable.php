<?php
$message = "Hello World!";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>2Variable</title>
        <link rel="stylesheet" type="text/css" href="styles.css"/>
    </head>
    <body>
        <div class="grid-container" style="--cols: 20fr 60fr 20fr; --rows: 20fr 60fr 20fr;">
            <div class="border center-2x2">
                <p class="main-text"><?= htmlspecialchars($message) ?></p>
            </div>
        </div>
    </body>
</html>