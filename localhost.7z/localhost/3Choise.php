<?php
    session_start();


    function validateLine($value){
        $_SESSION['validate_attempts'] = ($_SESSION['validate_attempts'] ?? 0) + 1;

        if(is_numeric($value) || empty($value) || str_contains($value, ' ') || !preg_match('/[а-яА-я]/u', $value)){
            $_SESSION['validate_error'] = "Некорректный ввод, попробуйте ещё раз! (Попытка №" . $_SESSION['validate_attempts'] . ")";
            
            return false;
        }

        unset($_SESSION['validate_error']);
        unset($_SESSION['validate_attempts']);

        return true;
    }

    function choice(){
        
        $_SESSION['choice_attempts'] = ($_SESSION['choice_attempts'] ?? 0) + 1;
        $input = strtolower(trim($_POST['answer'] ?? ''));

        if($input === "да"){
            unset($_SESSION['choice_error']);
            unset($_SESSION['choice_attempts']);

            return true;
        }
        elseif($input === "нет"){
            unset($_SESSION['choice_error']);
            unset($_SESSION['choice_attempts']);

            return false;
        }

        $_SESSION['choice_error'] = "Некорректный ввод №" . $_SESSION['choice_attempts'] . "Пожалуйста введите 'да' или 'нет':";

        return null;
    }

    $message = "Hello World!";
    $alternative_message = "Oh, Ok Goodbye!";
    $label = "3Choise";
    $question = "Входящие 1: Хотите увидеть сообщение? [да/нет]:";
    $showMessage = null;
    $error = '';

    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        if (validateLine($_POST['answer'])) {
            $showMessage = choice();
        }
    }
?>

<!DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <title><?= htmlspecialchars($label) ?></title>
        <link rel="stylesheet" type="text/css" href="styles.css"/>
    </head>
    <body>
        <div class="grid-container-base" style="--cols: 20fr 60fr 20fr; --rows: 20fr 60fr 20fr;">
            <div class="base-border center-2x2">
                <div class="grid-container-1x3" style="--rows: 10fr 10fr 80fr;">

                    <p class="main-text"><?= htmlspecialchars($question) ?></p>

                    <form method="POST" class="grid-container-2x1 align-center" style="--cols: 60fr 40fr;">

                        <input type="text"
                               name="answer"
                               class="ui-control main-text align-center"
                               style="font-size: 20px"
                               value="<?= htmlspecialchars($_POST['answer'] ?? '') ?>"/>

                        <input type="submit"
                               name="submit"
                               value="Отправить"
                               class="ui-control main-text"
                               style="padding: 0px 5px; background-color: #102A32"/>
                    </form>

                    <?php if(isset($_SESSION['validate_error'])): ?>
                        <p class="main-text error"><?= htmlspecialchars($_SESSION['validate_error']) ?></p>
                    
                    <?php elseif(isset($_SESSION['choice_error'])): ?>
                        <p class="main-text error"><?= htmlspecialchars($_SESSION['choice_error']) ?></p>

                    <?php elseif($showMessage === true): ?>
                        <p class="main-text" style="font-size: 32px"><?= htmlspecialchars($message) ?></p>
                    <?php elseif($showMessage === false): ?>
                        <p class="main-text" style="font-size: 32px"><?= htmlspecialchars($alternative_message) ?></p>
                    <?php else: ?>
                        <p class="main-text"></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </body>
</html>

<?php
    unset($_SESSION['validate_error']);
    unset($_SESSION['choice_error']);
?>