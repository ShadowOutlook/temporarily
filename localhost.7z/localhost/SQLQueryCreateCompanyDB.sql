USE [master]
GO

CREATE DATABASE CompanyDB;
GO

USE CompanyDB;
GO

CREATE TABLE UserAuthorization (
	UserAuthorizationId INT IDENTITY(1,1),
    UserLogin NVARCHAR(50) NOT NULL,
    UserPassword NVARCHAR(50) NOT NULL,
    CONSTRAINT PK_UserAuthorization_UserAuthorizationId PRIMARY KEY (UserAuthorizationId),
    CONSTRAINT UQ_UserAuthorization_UserLogin UNIQUE (UserLogin)
);
GO

CREATE TABLE Position (
    PositionId INT IDENTITY(1,1),
    PositionName NVARCHAR(50) NOT NULL,
    CONSTRAINT PK_Position_PositionId PRIMARY KEY (PositionId)
);
GO

CREATE TABLE Employee (
	EmployeeId INT IDENTITY(1,1),
	EmployeeSurname NVARCHAR(50) NOT NULL,
	EmployeeName NVARCHAR(50) NOT NULL,
    EmployeePatronymic NVARCHAR(50),
    PhoneNumber NVARCHAR(50) NOT NULL,
    Email NVARCHAR(50) NOT NULL,
    PositionId INT NOT NULL,
	CONSTRAINT PK_Employee_EmployeeId PRIMARY KEY (EmployeeId),
	CONSTRAINT UQ_Employee_Email UNIQUE (Email),
    CONSTRAINT FK_Employee_Position FOREIGN KEY (PositionId) REFERENCES Position(PositionId) ON DELETE CASCADE ON UPDATE CASCADE
);
GO

CREATE TABLE EmployeeAuth (
    EmployeeAuthId INT IDENTITY(1,1),
    Email NVARCHAR(50) NOT NULL,
    EmployeeLogin NVARCHAR(50) NOT NULL,
    CONSTRAINT PK_EmployeeAuth_EmployeeAuthId PRIMARY KEY (EmployeeAuthId),
    CONSTRAINT FK_EmployeeAuth_Email FOREIGN KEY (Email) REFERENCES Employee(Email) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT FK_EmployeeAuth_EmployeeLogin FOREIGN KEY (EmployeeLogin) REFERENCES UserAuthorization(UserLogin) ON DELETE CASCADE ON UPDATE CASCADE
);
GO

CREATE TABLE EmailMessage (
    EmailMessageId INT IDENTITY(1,1),
    FromWhom NVARCHAR(50) NOT NULL,
    ToWhom NVARCHAR(50) NOT NULL,
    EmailSubject NVARCHAR(50) NOT NULL,
    EmailMessage NVARCHAR(50) NOT NULL,
    CONSTRAINT PK_EmailMessage_EmailMessageId PRIMARY KEY (EmailMessageId),
    CONSTRAINT FK_EmailMessage_FromWhom FOREIGN KEY (FromWhom) REFERENCES Employee(Email) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT FK_EmailMessage_ToWhom FOREIGN KEY (ToWhom) REFERENCES Employee(Email) ON DELETE NO ACTION ON UPDATE NO ACTION
);
GO