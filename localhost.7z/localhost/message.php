<?php
function FormatErrors($errors) {
    foreach ($errors as $error) {
        echo "SQLSTATE: " . $error['SQLSTATE'] . "<br>";
        echo "Код: " . $error['code'] . "<br>";
        echo "Сообщение: " . $error['message'] . "<br>";
    }
}

function OpenConnection()
{
    $serverName = "tcp:H-WAY-SBR,1433";

    $connectionOptions = array("Database"=>"CompanyDB",
                               "Uid"=>"rentManagerLogin",
                               "PWD"=>"StrongRent123!");

    $conn = sqlsrv_connect($serverName, $connectionOptions);

        if($conn == false)
            die(FormatErrors(sqlsrv_errors()));
        else echo "Connection Success!" . "<br>";

        return $conn;
}

function ReadData()
{
    try
    {
        $conn = OpenConnection();

        $tsql = "SELECT TOP 1 TextMessage FROM EmailMessage WHERE TextMessage = ?";
        $params = array('Hello World');
        $getMessage = sqlsrv_query($conn, $tsql, $params);

        if ($getMessage == FALSE)
            die(FormatErrors(sqlsrv_errors()));
        else
        {
            while($row = sqlsrv_fetch_array($getMessage, SQLSRV_FETCH_ASSOC))
            {
                echo $row['TextMessage'] . "<br>";
            }
        }

        sqlsrv_close($conn);
    }
    catch(Exception $e)
    {
        echo("Error: " . $e->getMessage());
    }
}

ReadData();

?>