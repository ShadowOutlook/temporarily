<?php
function validateLine($value) {
    while (is_numeric($value) || empty($value) || str_contains($value, ' ') || !preg_match('/[а-яА-Я]/u', $value)) {
        echo "Некорректный ввод, попробуйте еще раз!:";
        $value = trim(fgets(STDIN)); // Для консоли
        // В веб-среде вместо этого нужно возвращать ошибку или перенаправлять
    }
    return $value;
}

function choice() {
    while (true) {
        $input = strtolower(validateLine(trim($_POST['answer'] ?? '')));
        
        if ($input === 'да') {
            return true;
        } elseif ($input === 'нет') {
            return false;
        } else {
            echo "Некорректный ввод. Пожалуйста введите 'да' или 'нет':";
            // В веб-среде нужно выводить сообщение об ошибке
        }
    }
}

// Обработка формы
$message = "Это ваше секретное сообщение!";
$label = "3Choise";
$question = "Входящие 1: Хотите увидеть сообщение? [да/нет]:";
$showMessage = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $showMessage = choice();
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?= htmlspecialchars($label) ?></title>
    <link rel="stylesheet" type="text/css" href="styles.css"/>
</head>
<body>
    <div class="grid-container-base" style="--cols: 20fr 60fr 20fr; --rows: 20fr 60fr 20fr;">
        <div class="border center-2x2">
            <div class="grid-container-4x1" style="--rows: 10fr 10fr 10fr 70fr;">
                <p class="main-text"><?= htmlspecialchars($question) ?></p>
                
                <form method="POST">
                    <input type="text"
                           name="answer"
                           class="ui-control main-text"
                           style="font-size: 20px"
                           value="<?= htmlspecialchars($_POST['answer'] ?? '') ?>"/>
                    
                    <input type="submit"
                           name="submit"
                           value="Отправить"
                           class="ui-control main-text"
                           style="background-color: #102A32"/>
                </form>
                
                <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                    <?php if ($showMessage): ?>
                        <p class="main-text"><?= htmlspecialchars($message) ?></p>
                    <?php else: ?>
                        <p class="main-text">Oh, ok Goodbye!</p>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <p class="error-text"><?= htmlspecialchars($error) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>