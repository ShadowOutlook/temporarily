<?php
    $lable = "4MessageBox";
    $singboard = "Сообщение";
    $message = "Hello World";
    $showbutton = "Показать сообщение";
    $okbutton = "OK";
?>

<DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <title><?= htmlspecialchars($lable) ?></title>
        <link rel="stylesheet" type="text/css" href="styles.css"/>
        <script>
            function showMsg(){
                document.getElementById("msgBox").style.display = "flex";
            }

            function closeMsg(){
                document.getElementById("msgBox").style.display = "none";
            }
        </script>
    </head>
    <body>
        <div class="grid-container-base" style="--cols: 25fr 50fr 25fr; --rows: 20fr 60fr 20fr;">

            <div class="base-border center-2x2">

                <div class="grid-container-1x2" style="--rows: 10fr 90fr;">

                    <div class="singboard">
                        <p class="headline"><?= htmlspecialchars($singboard) ?></p>
                    </div>
                    
                    <div class="grid-container-1x3" style="--rows: 1fr 1fr 1fr; height: auto">

                        <div class="button-wrapper" style="height: auto">
                            <button class="stretch-button" style="height: auto; min-height: 55px" onclick="showMsg()">
                                <?= htmlspecialchars($showbutton) ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal" id="msgBox">
                <div class="modal-content">

                    <p class="main-text"><?= htmlspecialchars($message) ?></p>

                    <button class="base-button" onclick="closeMsg()">
                        <p style="margin: 0px 5px"><?= htmlspecialchars($okbutton) ?></p>
                    </button>
                </div>
            </div>
        </div>
    </body>
</html>