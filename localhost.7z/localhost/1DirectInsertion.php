<?php
    $label="1DirectInsertion";
?>
<DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <title><?= htmlspecialchars($label) ?></title>
        <link rel="stylesheet" type="text/css" href="styles.css"/>
    </head>
    <body>
        <div class="grid-container-base" style="--cols: 20fr 60fr 20fr; --rows: 20fr 60fr 20fr;">
            <p class="main-text center-2x2" style="font-size: 128px"><?php echo "Hello World" ?></p>
        </div>
    </body>
</html>