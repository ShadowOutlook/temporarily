<?php
$lable = "5QuerySelect";
$singboard = "Сообщение";
$message = null; // Изменено на null для проверки
$showbutton = "Показать сообщение";
$okbutton = "OK";
$error = null; // Добавлена переменная для ошибок

function FormatErrors($errors) {
    $errorMessages = [];
    foreach ($errors as $error) {
        $errorMessages[] = "SQLSTATE: " . $error['SQLSTATE'] . "<br>" .
                          "Код: " . $error['code'] . "<br>" .
                          "Сообщение: " . $error['message'];
    }
    return implode("<br><br>", $errorMessages);
}

function OpenConnection() {
    $serverName = "tcp:H-WAY-SBR,1433";
    $connectionOptions = array(
        "Database" => "CompanyDB",
        "Uid" => "rentManagerLogin",
        "PWD" => "StrongRent123!"
    );

    $conn = sqlsrv_connect($serverName, $connectionOptions);
    if($conn == false) {
        return [false, FormatErrors(sqlsrv_errors())];
    }
    return [true, $conn];
}

function ReadData() {
    global $message, $error; // Используем глобальные переменные
    
    try {
        list($success, $result) = OpenConnection();
        if (!$success) {
            $error = $result;
            return;
        }
        $conn = $result;

        $tsql = "SELECT TOP 1 TextMessage FROM EmailMessage WHERE TextMessage = ?";
        $params = array('Hello World');
        $getMessage = sqlsrv_query($conn, $tsql, $params);

        if ($getMessage === false) {
            $error = FormatErrors(sqlsrv_errors());
        } else {
            $hasData = false;
            while($row = sqlsrv_fetch_array($getMessage, SQLSRV_FETCH_ASSOC)) {
                $message = $row['TextMessage'];
                $hasData = true;
            }
            
            if (!$hasData) {
                $message = "Запись 'Hello World' не найдена в базе данных";
            }
        }
        
        sqlsrv_close($conn);
    } catch(Exception $e) {
        $error = "Ошибка: " . $e->getMessage();
    }
}

// Вызываем функцию при POST-запросе (если нужно)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'read_data') {
    ReadData();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?= htmlspecialchars($lable) ?></title>
    <link rel="stylesheet" type="text/css" href="styles.css"/>
    <script>
        function readData() {
            // Можно реализовать AJAX-запрос здесь, если нужно
            document.forms['messageForm'].submit();
        }
    </script>
</head>
<body>
    <div class="grid-container-base" style="--cols: 25fr 50fr 25fr; --rows: 20fr 60fr 20fr;">

        <div class="base-border center-2x2">

            <form name="messageForm" class="constrained-form" method="post">

                <input type="hidden" name="action" value="read_data">
                
                <div class="grid-container-1x3" style="--rows: 10fr 30fr 60fr;">

                    <div class="singboard">
                        <p class="headline"><?= htmlspecialchars($singboard) ?></p>
                    </div>
                    
                    <div class="grid-container-1x3" style="--rows: 1fr 1fr 1fr; height: auto">

                        <div class="button-wrapper" style="height: auto">
                            <button type="button" class="stretch-button" style="height: auto; min-height: 55px" onclick="readData()">
                                <?= htmlspecialchars($showbutton) ?>
                            </button>
                        </div>
                    </div>

                    <div class="message-container">
                        <?php if ($error): ?>
                            <p class="main-text scrollable"><?= nl2br(htmlspecialchars($error)) ?></p>
                        <?php elseif (isset($message)): ?>
                            <p class="main-text scrollable"><?= htmlspecialchars($message) ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>