const offers = ["Начать сканирование товара",
                "Выберите пакет",
                "Напечатать чек?",
                "Выберите способ оплаты",
                "Копим или списываем бонусы?",
                "Карта заблокирована или недостаточно средств",
                "Спасибо за покупку"];

const buttonLabels = ["Начать",
                      "Без пакета",
                      "Маленький пакет",
                      "Большой пакет",
                      "Распечатать",
                      "Не печатать",
                      "СБП",
                      "Банковская карта",
                      "Бонусная карта",
                      "Копим",
                      "Списать"];

function LoadInitialState () {
    const container = document.getElementById('stage-container');

    container.innerHTML = `
        <p class="main-text">${offers[0]}</p>
        <div style="display: flex; justify-content: flex-end">
            <button type="button" class="base-button" onclick="startFirstStage()">
                ${buttonLabels[0]}
            </button>
        </div>
    `;
}

LoadInitialState();

function startFirstStage()
{
    const container = document.getElementById('stage-container');

    while(container.firstChild)
    {
        container.removeChild(container.firstChild);
    }

    container.innerHTML =  `
        <p class="main-text">${offers[1]}</p>
        <div style="display: flex; justify-content: flex-end">
            <button type="button" class="base-button" style="margin: 5px;" onclick="startSecondStage('without')">
                ${buttonLabels[1]}
            </button>
            <button type="button" class="base-button" style="margin: 5px;" onclick="startSecondStage('small')">
                ${buttonLabels[2]}
            </button>
            <button type="button" class="base-button" style="margin: 5px;" onclick="startSecondStage('big')">
                ${buttonLabels[3]}
            </button>
        </div>
    `;
}

function startSecondStage(type)
{
    switch (type) {
        case 'without':
            break;
        case 'small':
            
    }

    const container = document.getElementById('stage-container');

    while(container.firstChild)
    {
        container.removeChild(container.firstChild);
    }

    container.innerHTML =  `
        <p class="main-text">${offers[2]}</p>
        <div style="display: flex; justify-content: flex-end">
            <button type="button" class="base-button" style="margin: 5px;" onclick="startThirdStage()">
                ${buttonLabels[3]}
            </button>
            <button type="button" class="base-button" style="margin: 5px;" onclick="startThirdStage()">
                ${buttonLabels[3]}
            </button>
            <button type="button" class="base-button" style="margin: 5px;" onclick="startThirdStage()">
                ${buttonLabels[3]}
            </button>
        </div>
    `;
}