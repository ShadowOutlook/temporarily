const offers = ["Начать сканирование товара",
                "Выберите пакет",
                "Напечатать чек?",
                "Выберите способ оплаты",
                "Копим или списываем бонусы?",
                "Карта заблокирована или недостаточно средств",
                "Спасибо за покупку"];

const buttonLabels = ["Начать",
                      "Без пакета",
                      "Маленький пакет",
                      "Большой пакет",
                      "Распечатать",
                      "Не печатать",
                      "СБП",
                      "Банковская карта",
                      "Бонусная карта",
                      "Копим",
                      "Списать"];

const order = [];

function Connect()
{
    const Sequelize = require("sequelize");
    const sequelize = new Sequelize("BegemagDB", "rentManagerLogin", "StrongRent123!", {
    dialect: "mssql",
    host: "localhost",
    port: "1433"
});
}

function LoadInitialState()
{
    const mainContent = document.getElementById('main-frame');
    const auxiliaryContent = document.getElementById('auxiliary-frame');

    mainContent.innerHTML = `<p class="main-text">${offers[0]}</p>`;
    auxiliaryContent.innerHTML = `<button type="button" class="base-button" onclick="startFirstStage()">
                                     ${buttonLabels[0]}
                                 </button>`;
}

LoadInitialState();

function startFirstStage()
{
    const mainContent = document.getElementById('main-frame');
    const auxiliaryContent = document.getElementById('auxiliary-frame');

    while(mainContent.firstChild)
    {
        mainContent.removeChild(mainContent.firstChild);
    }

    while(auxiliaryContent.firstChild) 
    {
        auxiliaryContent.removeChild(auxiliaryContent.firstChild);
    }

    mainContent.innerHTML = `<p class="main-text">${offers[1]}</p>`;
    auxiliaryContent.innerHTML = `<button type="button" class="base-button" style="margin: 5px;" onclick="startSecondStage('without')">
                                     ${buttonLabels[1]}
                                 </button>
                                 <button type="button" class="base-button" style="margin: 5px;" onclick="startSecondStage('small')">
                                     ${buttonLabels[2]}
                                 </button>
                                 <button type="button" class="base-button" style="margin: 5px;" onclick="startSecondStage('big')">
                                     ${buttonLabels[3]}
                                 </button>`;
}

function startSecondStage(type)
{
    switch (type) {
        case 'without':
            break;
        case 'small':
            
    }

    const container = document.getElementById('stage-container');

    while(container.firstChild)
    {
        container.removeChild(container.firstChild);
    }

    container.innerHTML =  `
        <p class="main-text">${offers[2]}</p>
        <div style="display: flex; justify-content: flex-end">
            <button type="button" class="base-button" style="margin: 5px;" onclick="startThirdStage()">
                ${buttonLabels[3]}
            </button>
            <button type="button" class="base-button" style="margin: 5px;" onclick="startThirdStage()">
                ${buttonLabels[3]}
            </button>
            <button type="button" class="base-button" style="margin: 5px;" onclick="startThirdStage()">
                ${buttonLabels[3]}
            </button>
        </div>
    `;
}