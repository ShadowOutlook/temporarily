const titles = ["Начальное меню",
                "Выбор пакета",
                "Заказ",
                "Оплата",
                "Бонусная карта",
                "Неудачная транзакция",
                "Печать чека",
                "Завершение смены"];

const offers = ["Начать сканирование товара",
                "Выберите пакет",
                "Выберите способ оплаты",
                "Копим или списываем бонусы?",
                "Карта заблокирована или недостаточно средств",
                "Напечатать чек?",
                "Спасибо за покупку"];

const buttonLabels = ["Начать",
                      "Без пакета",
                      "Маленький пакет",
                      "Большой пакет",
                      "Добавить",
                      "Перейти к оплате",
                      "СБП",
                      "Банковская карта",
                      "Бонусная карта",
                      "Копим",
                      "Списать",
                      "Распечатать",
                      "Не печатать",];

const labels = ["Код товара", "Количество"];

const order = [];

const Sequelize = require("sequelize");

// подключение express
const express = require("express");

// создаем объект приложения
const app = express();

//создаем парсер для получения отправленных данных
const urlencodedParser = express.urlencoded({extended: false});

// определяем объект Sequelize
const sequelize = new Sequelize("BegemagDB", "rentManagerLogin", "StrongRent123!", {
    dialect: "mssql",
    host: "localhost",
    port: "1433"
});

// определяем модель Customer
const Customer = sequelize.define("customer", {
  customerid: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false
  },
  customername: {
    type: Sequelize.STRING,
    allowNull: false
  },
  phonenumber: {
    type: Sequelize.INTEGER,
    allowNull: false
  }
});

// Установка Handlebars в качестве движка представлений в Express
app.set("view engine", "hbs");

// синхронизация с бд, после успешной синхронизации запускаем сервер
sequelize.sync().then(()=>{
  app.listen(3000, function(){
    console.log("Сервер ожидает подключения...");
  });
}).catch(err=>console.log(err));

// Пути к статическим файлам - компонентам middleware в конвейер обработки запроса
app.use(express.static("html"));
app.use(express.static("css"));
app.use(express.static("js"));
app.use(express.static("php"));


// определяем обработчик для маршрута "/"
app.get("/", function(request, response)
{
    response.render("index.hbs", {
        title: titles[0],
        offer: offers[0],
        buttonLabel: buttonLabels[0]
    });
});

//Загрузка страницы выбора пакета при нажатии на кнопку начала сканирования товара
app.post("/start-scanning", function(request, response)
{
    response.render("add-package.hbs", {
        title: titles[1],
        offer: offers[1],
        buttonLabel1: buttonLabels[1],
        buttonLabel2: buttonLabels[2],
        buttonLabel3: buttonLabels[3]
    });
});

//Переадресация на страницу оформления заказа
app.post("/add-package", urlencodedParser, function(request, response)
{
    //request.body инкапсулирует данные формы
    const selectedPackage = request.body.package;

    switch (selectedPackage) {
        case "small":
            // логика проверки наличия маленького пакета в БД
            
            break;
        case "big":
            // логика проверки наличия большого пакета в БД
            
            break;
        case "none":
            break;
    }

    response.redirect("/order");
});

//Загрузка страницы оформления заказа
app.get("/order", function(request, response)
{
    response.render("order.hbs", {
        title: titles[2],
        label1: labels[0],
        label2: labels[1],
        buttonLabel1: buttonLabels[4],
        buttonLabel2: buttonLabels[5],
    });
});

//Обработка добавления товара и перехода к оплате
app.post("/add-product", urlencodedParser, function(request, response)
{
    //request.body инкапсулирует данные формы
    const { productId, productCount } = request.body;

    if (request.body.pay !== undefined)
    {
        // Кнопка "перейти к оплате" была нажата
        return response.redirect('/payment');
    }
});

//Загрузка страницы выбора способа оплаты
app.get("/payment", function(request, response)
{
    response.render("payment.hbs", {
        title: titles[3],
        offer: offers[2],
        buttonLabel1: buttonLabels[6],
        buttonLabel2: buttonLabels[7],
        buttonLabel3: buttonLabels[8]
    });
});

// начинаем прослушивать подключения на 3000 порту
app.listen(3000);