// подключение express
const express = require("express");
const fs = require("fs");
// создаем объект приложения
const app = express();
app.use(express.static("html"));
app.use(express.static("css"));
app.use(express.static("js"));
app.use(express.static("php"));
// определяем обработчик для маршрута "/"
app.get("/", function(request, response){
     
    let data = fs.readFileSync("selfcheckout.html", "utf-8");
    response.send(data);
});
// начинаем прослушивать подключения на 3000 порту
app.listen(3000);