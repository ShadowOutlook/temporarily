﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicCreate
{
    public class Admin
    {
        [Key]
        public int AdminId { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }

        public virtual User User { get; set; }

    }
}
