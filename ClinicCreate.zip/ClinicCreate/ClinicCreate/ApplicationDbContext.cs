﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace ClinicCreate
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext() : base("DbConnection")
        {

        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Patient> Patients { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //Нейминг таблиц в БД
            modelBuilder.Entity<Category>().ToTable("Category");
            modelBuilder.Entity<User>().ToTable("User");
            modelBuilder.Entity<Doctor>().ToTable("Doctor");
            modelBuilder.Entity<Patient>().ToTable("Patient");
            modelBuilder.Entity<Admin>().ToTable("Admin");

            //Разрешить запретить значение null
            modelBuilder.Entity<Category>()
                .Property(c => c.CategoryId)
                .IsRequired();
            modelBuilder.Entity<Category>()
                .Property(c => c.Name)
                .IsRequired();

            //Разрешить запретить значение null
            modelBuilder.Entity<User>()
                .Property(u => u.UserId)
                .IsRequired();
            modelBuilder.Entity<User>()
                .Property(u => u.Login)
                .IsRequired();
            modelBuilder.Entity<User>()
                .Property(u => u.Password)
                .IsRequired();
            modelBuilder.Entity<User>()
                .Property(u => u.Type)
                .IsRequired();

            //Связь по внешнему ключу многие к одному
            modelBuilder.Entity<Doctor>()
                 .HasRequired(d => d.Category)
                 .WithMany()
                 .HasForeignKey(d => d.CategoryId)
                 .WillCascadeOnDelete(false);
            //Связь по внешнему ключу один к одному
            modelBuilder.Entity<Doctor>()
                .HasRequired(d => d.User)
                .WithOptional(u => u.Doctor)
                .Map(m => m.MapKey("UserId"));
            //Разрешить запретить значение null
            modelBuilder.Entity<Doctor>()
                .Property(d => d.DoctorId)
                .IsRequired();
            modelBuilder.Entity<Doctor>()
                .Property(d => d.Surname)
                .IsRequired();
            modelBuilder.Entity<Doctor>()
                .Property(d => d.Name)
                .IsRequired();
            modelBuilder.Entity<Doctor>()
                .Property(d => d.Patronymic)
                .IsOptional();
            modelBuilder.Entity<Doctor>()
                .Property(d => d.CategoryId)
                .IsRequired();
            modelBuilder.Entity<Doctor>()
                .Property(d => d.DateOfBirth)
                .IsRequired();

            //Связь по внешнему ключу один к одному
            modelBuilder.Entity<Patient>()
                .HasRequired(p => p.User)
                .WithOptional(u => u.Patient)
                .Map(m => m.MapKey("UserId"));
            //Разрешить запретить значение null
            modelBuilder.Entity<Patient>()
                .Property(u => u.PatientId)
                .IsRequired();
            modelBuilder.Entity<Patient>()
                .Property(u => u.Surname)
                .IsRequired();
            modelBuilder.Entity<Patient>()
                .Property(u => u.Name)
                .IsRequired();
            modelBuilder.Entity<Patient>()
                .Property(u => u.Patronymic)
                .IsOptional();
            modelBuilder.Entity<Patient>()
                .Property(u => u.DateOfBirth)
                .IsRequired();
            modelBuilder.Entity<Patient>()
                .Property(u => u.NumPolice)
                .IsRequired();
            modelBuilder.Entity<Patient>()
                .Property(u => u.InsuranceCompany)
                .IsRequired();

            //Связь по внешнему ключу один к одному
            modelBuilder.Entity<Admin>()
                .HasRequired(a => a.User)
                .WithOptional(u => u.Admin)
                .Map(m => m.MapKey("UserId"));
            //Разрешить запретить значение null
            modelBuilder.Entity<Admin>()
                .Property(u => u.AdminId)
                .IsRequired();
            modelBuilder.Entity<Admin>()
                .Property(u => u.Surname)
                .IsRequired();
            modelBuilder.Entity<Admin>()
                .Property(u => u.Name)
                .IsRequired();
        }
    }
}
