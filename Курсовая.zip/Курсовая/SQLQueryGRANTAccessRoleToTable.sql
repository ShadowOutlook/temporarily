-- �������� �� ������ (rentManager)
GRANT SELECT, INSERT, UPDATE, DELETE ON Customer TO rentManagerRole;
GRANT SELECT ON Make TO rentManagerRole;
GRANT SELECT ON Model TO rentManagerRole;
GRANT SELECT ON CarClass TO rentManagerRole;
GRANT SELECT ON CarStatus TO rentManagerRole;
GRANT SELECT, INSERT, UPDATE ON Branch TO rentManagerRole;
GRANT SELECT, INSERT, UPDATE, DELETE ON Car TO rentManagerRole;
GRANT SELECT ON RentalStatus TO rentManagerRole;
GRANT SELECT, INSERT, UPDATE, DELETE ON Rental TO rentManagerRole;
GRANT SELECT ON PaymentType TO rentManagerRole;
GRANT SELECT, INSERT, UPDATE ON Payment TO rentManagerRole;
GRANT SELECT, INSERT, UPDATE ON Penalty TO rentManagerRole;
GRANT SELECT, INSERT, UPDATE ON Maintenance TO rentManagerRole;
GRANT SELECT ON Position TO rentManagerRole;
GRANT SELECT ON Department TO rentManagerRole;
GRANT SELECT ON Employee TO rentManagerRole;
GRANT SELECT, INSERT, UPDATE ON BranchEmployee TO rentManagerRole;

-- ������������� ����� (emplOffice)
GRANT SELECT, INSERT, UPDATE ON Customer TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON Make TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON Model TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON CarClass TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON CarStatus TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE, DELETE ON Branch TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON Car TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON RentalStatus TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON Rental TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON PaymentType TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON Payment TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON Penalty TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON Maintenance TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON Position TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON Department TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON Employee TO emplOfficeRole;
GRANT SELECT, INSERT, UPDATE ON BranchEmployee TO emplOfficeRole;

-- ���������� �������� (emplFinance)
GRANT SELECT ON Customer TO emplFinanceRole;
GRANT SELECT ON Make TO emplFinanceRole;
GRANT SELECT ON Model TO emplFinanceRole;
GRANT SELECT ON CarClass TO emplFinanceRole;
GRANT SELECT ON CarStatus TO emplFinanceRole;
GRANT SELECT ON Branch TO emplFinanceRole;
GRANT SELECT ON Car TO emplFinanceRole;
GRANT SELECT ON RentalStatus TO emplFinanceRole;
GRANT SELECT ON Rental TO emplFinanceRole;
GRANT SELECT, INSERT, UPDATE, DELETE ON PaymentType TO emplFinanceRole;
GRANT SELECT, INSERT, UPDATE, DELETE ON Payment TO emplFinanceRole;
GRANT SELECT, INSERT, UPDATE, DELETE ON Penalty TO emplFinanceRole;
GRANT SELECT ON Maintenance TO emplFinanceRole;
GRANT SELECT ON Position TO emplFinanceRole;
GRANT SELECT ON Department TO emplFinanceRole;
GRANT SELECT ON Employee TO emplFinanceRole;
GRANT SELECT ON BranchEmployee TO emplFinanceRole;

-- ���������� (emplMarket)
GRANT SELECT ON Customer TO emplMarketRole;
GRANT SELECT ON Make TO emplMarketRole;
GRANT SELECT ON Model TO emplMarketRole;
GRANT SELECT ON CarClass TO emplMarketRole;
GRANT SELECT ON CarStatus TO emplMarketRole;
GRANT SELECT ON Branch TO emplMarketRole;
GRANT SELECT ON Car TO emplMarketRole;
GRANT SELECT ON RentalStatus TO emplMarketRole;
GRANT SELECT ON Rental TO emplMarketRole;
GRANT SELECT ON PaymentType TO emplMarketRole;
GRANT SELECT ON Payment TO emplMarketRole;
GRANT SELECT ON Penalty TO emplMarketRole;
GRANT SELECT ON Maintenance TO emplMarketRole;
GRANT SELECT ON Position TO emplMarketRole;
GRANT SELECT ON Department TO emplMarketRole;
GRANT SELECT ON Employee TO emplMarketRole;
GRANT SELECT ON BranchEmployee TO emplMarketRole;
