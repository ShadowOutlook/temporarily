DECLARE @TempTable TABLE (
	CarId INT,
	VIN NVARCHAR(50),
    MakeName NVARCHAR(50),
	ModelName NVARCHAR(50),
	[Year] INT,
	ClassName NVARCHAR(50),
	StatusName NVARCHAR(50),
    DailyRate INT,
	BranchName NVARCHAR(100)
);

INSERT INTO @TempTable
SELECT CarId, VIN, MakeName, ModelName, [Year], ClassName, StatusName, DailyRate, BranchName
FROM Car
	INNER JOIN Model ON Car.ModelId = Model.ModelId
	INNER JOIN Make ON Model.MakeId = Make.MakeId
	INNER JOIN CarClass ON Car.ClassId = CarClass.ClassId
	INNER JOIN CarStatus ON Car.StatusId = CarStatus.StatusId
	LEFT JOIN Branch ON Car.BranchId = Branch.BranchId;

SELECT * FROM @TempTable;