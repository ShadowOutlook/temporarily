CREATE ROLE rentManagerRole;

CREATE ROLE emplofficeRole;

CREATE ROLE emplFinanceRole;

CREATE ROLE emplMarketRole;
