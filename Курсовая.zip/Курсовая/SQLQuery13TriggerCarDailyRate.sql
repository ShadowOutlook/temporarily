CREATE TRIGGER trg_ValidateCarRate
ON Car
INSTEAD OF INSERT
AS
BEGIN
    DECLARE @ClassName NVARCHAR(50), @MinRate INT, @MaxRate INT;

    IF EXISTS (
        SELECT 1 
        FROM inserted i
        INNER JOIN CarClass cc ON i.ClassId = cc.ClassId
        WHERE i.DailyRate < cc.MinRate OR i.DailyRate > cc.MaxRate
    )
    BEGIN
        SELECT @ClassName = cc.ClassName, @MinRate = cc.MinRate, @MaxRate = cc.MaxRate
        FROM inserted i
        INNER JOIN CarClass cc ON i.ClassId = cc.ClassId
        WHERE i.DailyRate < cc.MinRate OR i.DailyRate > cc.MaxRate;
        
        RAISERROR ('DailyRate �� ������������� ��������� ������ ����������. ClassName = %s, MinRate = %d, MaxRate = %d', 16, 1, @ClassName, @MinRate, @MaxRate);
        ROLLBACK;
    END
    ELSE
    BEGIN
        INSERT INTO Car (VIN, MakeId, ModelId, [Year], ClassId, StatusId, DailyRate, BranchId)
        SELECT VIN, MakeId, ModelId, [Year], ClassId, StatusId, DailyRate, BranchId
        FROM inserted;
    END
END;

