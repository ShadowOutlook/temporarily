CREATE VIEW vw_CustomerRentals AS
SELECT c.CustomerId, c.CustomerSurname, c.CustomerName, COUNT(r.RentalId) AS RentalCount
FROM Customer c
LEFT JOIN Rental r ON c.CustomerId = r.CustomerId
GROUP BY c.CustomerId, c.CustomerSurname, c.CustomerName;
