SELECT CustomerId, CustomerSurname, CustomerName, PhoneNumber, Email
FROM Customer
ORDER BY CustomerSurname;
