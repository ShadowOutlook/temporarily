SELECT RentalId, DATEDIFF(DAY, StartDate, EndDate) AS RentalDays
FROM Rental
WHERE StatusId = 2;