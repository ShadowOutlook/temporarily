SELECT c.ClassName, COUNT(car.CarId) AS CarCount
FROM Car car
INNER JOIN CarClass c ON car.ClassId = c.ClassId
GROUP BY c.ClassName
ORDER BY CarCount DESC;