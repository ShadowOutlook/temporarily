CREATE PROCEDURE GetAvailableCarsByBranch
    @BranchId INT
AS
BEGIN
    SELECT CarId, VIN, MakeName, ModelName, DailyRate, BranchName, [Location]
    FROM Car
		INNER JOIN Model ON Car.ModelId = Model.ModelId
		INNER JOIN Make ON Model.MakeId = Make.MakeId
		INNER JOIN Branch ON Car.BranchId = Branch.BranchId
    WHERE Car.BranchId = @BranchId
    AND StatusId = (SELECT StatusId FROM CarStatus WHERE StatusName = '��������');
END;
GO

EXEC GetAvailableCarsByBranch @BranchId = 2;
GO