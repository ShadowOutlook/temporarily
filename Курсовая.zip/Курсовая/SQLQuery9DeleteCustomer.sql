DELETE FROM Customer
WHERE CustomerId = 10;