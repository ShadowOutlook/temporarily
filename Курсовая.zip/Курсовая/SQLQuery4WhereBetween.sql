SELECT CarId, VIN, [Year], DailyRate
FROM Car
WHERE [Year] BETWEEN '2020-01-01' AND '2023-12-31'
AND StatusId = (SELECT StatusId FROM CarStatus WHERE StatusName = '��������');