SELECT pt.PaymentName, SUM(p.Amount) AS TotalAmount
FROM Payment p
INNER JOIN PaymentType pt ON p.PaymentTypeId = pt.PaymentTypeId
GROUP BY pt.PaymentName
HAVING SUM(p.Amount) > 10000;