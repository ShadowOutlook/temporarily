CREATE VIEW vw_BranchCarCount
WITH SCHEMABINDING
AS
SELECT
	b.BranchId,
	b.BranchName,
	COUNT_BIG(*) AS CarCount
FROM dbo.Branch b
	INNER JOIN dbo.Car c ON b.BranchId = c.BranchId
GROUP BY b.BranchId, b.BranchName;
GO

CREATE UNIQUE CLUSTERED INDEX IX_vw_BranchCarCount
ON vw_BranchCarCount (BranchId);
GO
