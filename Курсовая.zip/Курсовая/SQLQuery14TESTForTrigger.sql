INSERT INTO Car(VIN, MakeId, ModelId, [Year], ClassId, StatusId, DailyRate, BranchId)
VALUES
	('JT2BG22K0J0123457', (SELECT MakeId FROM Model WHERE ModelId = 1), 1, '2018', 2, 2, '300000', 1);