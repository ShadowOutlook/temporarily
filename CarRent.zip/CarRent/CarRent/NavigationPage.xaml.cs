﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarRent
{
    /// <summary>
    /// Логика взаимодействия для NavigationPage.xaml
    /// </summary>
    public partial class NavigationPage : Page
    {
        public ObservableCollection<Customer> Customers { get; set; }
        public ObservableCollection<Make> Makes { get; set; }

        public NavigationPage()
        {
            InitializeComponent();
            // Скрыть все DataGrid
            CustomerDataGrid.Visibility = Visibility.Collapsed;
            MakeDataGrid.Visibility = Visibility.Collapsed;
            Customers = new ObservableCollection<Customer>();
            Makes = new ObservableCollection<Make>();
            DataContext = this;
            LoadTableNames();
        }

        private void LoadCustomers()
        {
            Customers.Clear(); // Очищаем существующую коллекцию

            string connectionString = ConfigurationManager.ConnectionStrings["CarRentalDB"].ConnectionString;
            string formattedConnectionString = string.Format(connectionString, MainPage.userLogin, MainPage.userPassword);

            using (SqlConnection connection = new SqlConnection(formattedConnectionString))
            {
                string query = "SELECT CustomerId, CustomerSurname, CustomerName, CustomerPatronymic, PhoneNumber, Email, DriveLicense, Address FROM Customer";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Customers.Add(new Customer
                    {
                        CustomerId = reader.GetInt32(0),
                        CustomerSurname = reader.IsDBNull(1) ? null : reader.GetString(1),
                        CustomerName = reader.IsDBNull(2) ? null : reader.GetString(2),
                        CustomerPatronymic = reader.IsDBNull(3) ? null : reader.GetString(3),
                        PhoneNumber = reader.IsDBNull(4) ? null : reader.GetString(4),
                        Email = reader.IsDBNull(5) ? null : reader.GetString(5),
                        DriveLicense = reader.IsDBNull(6) ? null : reader.GetString(6),
                        Address = reader.IsDBNull(7) ? null : reader.GetString(7)
                    });
                }
            }
        }

        private void LoadMakes()
        {
            Makes.Clear(); // Очищаем существующую коллекцию

            string connectionString = ConfigurationManager.ConnectionStrings["CarRentalDB"].ConnectionString;
            string formattedConnectionString = string.Format(connectionString, MainPage.userLogin, MainPage.userPassword);

            using (SqlConnection connection = new SqlConnection(formattedConnectionString))
            {
                string query = "SELECT MakeId, MakeName FROM Make";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Makes.Add(new Make
                    {
                        MakeId = reader.GetInt32(0),
                        MakeName = reader.IsDBNull(1) ? null : reader.GetString(1)
                    });
                }
            }
        }

        private void LoadTableNames()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["CarRentalDB"].ConnectionString;
            string formattedConnectionString = string.Format(connectionString, MainPage.userLogin, MainPage.userPassword);
            List<string> tableNames = new List<string>();
            tableNames.Add("Выбор таблицы");
            using (SqlConnection connection = new SqlConnection(formattedConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_CATALOG = 'CarRental'", connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    tableNames.Add(reader["TABLE_NAME"].ToString());
                }
            }
            cmbTables.ItemsSource = tableNames;
            cmbTables.SelectedIndex = 0;
        }

        private void TablesComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbTables.SelectedIndex > 0)
            {
                string selectedTable = cmbTables.SelectedItem.ToString();

                // Скрыть все DataGrid
                CustomerDataGrid.Visibility = Visibility.Collapsed;
                MakeDataGrid.Visibility = Visibility.Collapsed;

                // Загрузить данные в зависимости от выбранной таблицы
                try
                {
                    switch (selectedTable)
                    {
                        case "Customer":
                            LoadCustomers();
                            CustomerDataGrid.Visibility = Visibility.Visible;
                            break;
                        case "Make":
                            LoadMakes();
                            MakeDataGrid.Visibility = Visibility.Visible;
                            break;
                        default:
                            MessageBox.Show("Неизвестная таблица!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            break;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                CustomerDataGrid.Visibility = Visibility.Collapsed;
                MakeDataGrid.Visibility = Visibility.Collapsed;
            }
        }

        private void btnOpen_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
