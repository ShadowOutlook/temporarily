﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarRent
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public static string userLogin { get; set; }
        public static string userPassword { get; set; }
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            userLogin = tbxLogin.Text;
            userPassword = tbxPassword.Password;

            if(AuthenticateUser(userLogin, userPassword))
            {
                NavigationWindow navigationWindow = new NavigationWindow();
                navigationWindow.Show();
                App.Current.MainWindow.Close();
            }
        }

        private bool AuthenticateUser(string userLogin, string userPassword)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["CarRentalDB"].ConnectionString;
            string formattedConnectionString = string.Format(connectionString, userLogin, userPassword);
            try
            {
                using (SqlConnection connection = new SqlConnection(formattedConnectionString))
                {
                    connection.Open();
                    return true;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка SQL", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }
    }
}
